"""职航罗盘 · 学生职业规划大数据平台（采集 MySQL → 标注 → 分析 → 学习路径 → 报告）

一个页面六个标签，从采数据到出 Word 报告不用切页面。
支持多专业：侧边栏选专业，课程数据按《职业教育专业教学标准》分专业存放，
课程覆盖、学习路径、相关课程、诊断报告全部按所选专业重算。

数据怎么流：
    智联公开搜索页
        └─ 采集线程 ──► MySQL（主库：jobs / crawl_progress / crawl_log）
                   └──► SQLite（分析快照：data/jobs.db）

为什么留一份快照：分析层（core/analyze.py）用 pandas 整表读取做回归和共现，
读本地 SQLite 是毫秒级；MySQL 做主库负责断点、日志、可追溯。两边同步由采集线程
顺手完成，页面上还有「重建分析库」按钮可以强对齐。

启动：
    双击 启动_职航罗盘.bat    或    .venv\\Scripts\\python -m streamlit run app_all.py
"""
from __future__ import annotations

import json
import re
import sqlite3
import sys
import threading
import time
from datetime import datetime
from pathlib import Path

import pandas as pd
import streamlit as st

try:
    import pymysql
except ImportError:            # 没装驱动时页面照样能开，只是采集不可用
    pymysql = None

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from core import agent as AG  # noqa: E402
from core import analyze as A  # noqa: E402
from core import crawl as ZP  # noqa: E402
from core import majors as MJ  # noqa: E402
from core import pathway as PW  # noqa: E402
from core import semantic as SEM  # noqa: E402
from core import skills as SK  # noqa: E402
from core import viz  # noqa: E402

SQLITE_DB = ROOT / "data" / "jobs.db"

st.set_page_config(page_title="职航罗盘 · 学生职业规划大数据平台", page_icon="🧭",
                   layout="wide", initial_sidebar_state="expanded")

st.markdown("""
<style>
  :root{
    --blue-900:#0b3f7a; --blue-800:#0f4d92; --blue-700:#1565c0; --blue-600:#1d6fd1;
    --blue-500:#2f8fe0; --blue-100:#dbe9f7; --blue-50:#eef6ff;
    --ink:#0f2744; --muted:#5b7a9d;
  }
  .stApp{background:linear-gradient(180deg,#eaf4ff 0,#f7fbff 320px,#f7fbff 100%)}
  .block-container{padding-top:1.3rem;padding-bottom:3rem;max-width:1560px}
  h1,h2,h3{letter-spacing:0;color:var(--blue-900)}
  h2{border-left:5px solid var(--blue-700);padding-left:10px;margin-top:.5em!important}
  h3{color:var(--blue-800)}

  /* 顶部品牌头图 */
  .hero{position:relative;overflow:hidden;border-radius:18px;padding:26px 32px 24px;
        background:linear-gradient(120deg,#0b3f7a 0%,#1565c0 58%,#2f8fe0 100%);
        box-shadow:0 12px 30px rgba(11,63,122,.22);margin-bottom:14px}
  .hero:after{content:"";position:absolute;right:-70px;top:-80px;width:260px;height:260px;
              border-radius:50%;background:rgba(255,255,255,.10)}
  .hero:before{content:"";position:absolute;right:90px;bottom:-120px;width:220px;height:220px;
               border-radius:50%;background:rgba(255,255,255,.06)}
  .hero .brand{font-size:13px;letter-spacing:3px;color:#bfe0ff;font-weight:600}
  .hero h1{color:#fff;font-size:29px;margin:6px 0 0;line-height:1.35}
  .hero .sub{color:#d8ebff;font-size:14px;margin-top:8px;line-height:1.7}
  .hero .chips{display:flex;gap:10px;margin-top:18px;flex-wrap:wrap;position:relative;z-index:2}
  .hero .chip{background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.26);
              border-radius:999px;padding:6px 14px;font-size:12.5px;color:#eaf5ff}
  .hero .chip b{font-size:16px;color:#fff;margin-left:4px}

  /* 侧边栏：深蓝底 */
  [data-testid="stSidebar"]{background:linear-gradient(180deg,#0b3f7a 0%,#12457f 55%,#0a2d57 100%)}
  [data-testid="stSidebar"] h3,[data-testid="stSidebar"] h2{color:#fff}
  [data-testid="stSidebar"] .flat{color:#c9e0f8}
  [data-testid="stSidebar"] label{color:#d8ebff!important}
  [data-testid="stSidebar"] .stSelectbox div[data-baseweb="select"]>div{
      background:#fff;border:1px solid rgba(255,255,255,.35);border-radius:9px}
  [data-testid="stSidebar"] [data-baseweb="select"] *{color:#0b3f7a!important}
  [data-testid="stSidebar"] .stButton>button{background:rgba(255,255,255,.12);color:#fff;
      border:1px solid rgba(255,255,255,.4)}
  [data-testid="stSidebar"] .stButton>button:hover{background:rgba(255,255,255,.22);color:#fff}
  .major-chip{background:rgba(255,255,255,.10);border:1px solid rgba(255,255,255,.22);
      border-radius:10px;padding:10px 12px;font-size:12px;line-height:1.75;color:#d8ebff;margin-top:4px}
  .major-chip b{color:#fff}

  /* 选项卡 */
  .stTabs [data-baseweb="tab-list"]{gap:6px;background:#e4effb;padding:6px;border-radius:12px;
      border:1px solid #d3e5f8}
  .stTabs [data-baseweb="tab"]{height:42px;border-radius:8px;color:#3b5f86;font-weight:600;
      padding:0 16px;background:transparent}
  .stTabs [data-baseweb="tab"]:hover{background:#f2f8ff;color:#1565c0}
  .stTabs [aria-selected="true"]{background:#fff!important;color:#1d4ed8!important;
      box-shadow:0 2px 8px rgba(13,74,138,.12)}
  .stTabs [data-baseweb="tab-highlight"]{background:transparent}

  /* KPI 卡片 */
  .kpi{background:linear-gradient(180deg,#fff 0,#f6fbff 100%);border:1px solid var(--blue-100);
       border-left:4px solid var(--blue-700);border-radius:12px;padding:13px 16px;height:100%;
       box-shadow:0 3px 12px rgba(13,74,138,.06)}
  .kpi .k{font-size:12px;color:var(--muted);font-weight:600}
  .kpi .v{font-size:26px;font-weight:700;color:var(--blue-900);line-height:1.35}
  .kpi .s{font-size:11.5px;color:#7f9cbb}

  .note{background:#fff8e6;border-left:3px solid #f0a020;padding:10px 14px;border-radius:0 8px 8px 0;
        font-size:13px;color:#7a4a00;line-height:1.7}
  .flat{color:var(--muted);font-size:13px;line-height:1.8}
  .blk{border:1px solid var(--blue-100);border-radius:10px;padding:12px 14px;background:#fff;font-size:13.5px}
  .mono{font-family:ui-monospace,Consolas,monospace;font-size:12px;line-height:1.7;
        white-space:pre-wrap;color:#123a63;margin-top:8px;
        background:#f4f9ff;border:1px solid #dbe9f7;border-radius:8px;padding:8px 10px}
  .tag{display:inline-block;padding:1px 9px;border-radius:20px;font-size:12px;font-weight:600}
  .run{background:#e3f2fd;color:#0d47a1}
  .stop{background:#fff3e0;color:#e65100}
  .idle{background:#eceff1;color:#455a64}
  .warn{background:#fef2f2;color:#991b1b}

  /* 图表卡片 */
  .fig{background:#fff;border:1px solid var(--blue-100);border-radius:14px;padding:18px 20px;
       box-shadow:0 5px 18px rgba(13,74,138,.07)}
  .fig svg{display:block;margin:0 auto;max-width:100%!important}
  .fig .cap{font-size:12.5px;color:var(--muted);margin-top:6px;line-height:1.7}

  /* 按钮 */
  .stButton>button,.stDownloadButton>button{border-radius:9px;border:1px solid #c7ddf5;
       background:#fff;color:#134a8e;font-weight:600;transition:all .15s}
  .stButton>button:hover,.stDownloadButton>button:hover{border-color:#2f8fe0;color:#0d47a1;
       background:#f2f8ff}
  .stButton>button[kind="primary"]{background:linear-gradient(135deg,#2563eb,#1d4ed8);
       color:#fff;border:none;box-shadow:0 5px 14px rgba(37,99,235,.26)}
  .stButton>button[kind="primary"]:hover{background:linear-gradient(135deg,#1d4ed8,#1740b0);color:#fff}

  /* 数据表 / 展开面板 / 提示 */
  [data-testid="stDataFrame"]{border:1px solid var(--blue-100);border-radius:12px;overflow:hidden}
  div[data-testid="stExpander"]{border:1px solid var(--blue-100);border-radius:12px;background:#fff}
  div[data-testid="stExpander"] summary{font-size:13.5px;color:var(--blue-800);font-weight:600}
  div[data-testid="stVerticalBlockBorderWrapper"]{background:#fff;border-radius:14px!important;
       border:1px solid var(--blue-100)!important;box-shadow:0 4px 16px rgba(13,74,138,.05)}
  div[data-testid="stVerticalBlockBorderWrapper"] p{line-height:1.85;margin-bottom:.4em}
  div[data-testid="stVerticalBlockBorderWrapper"] li{line-height:1.8}
  div[data-testid="stVerticalBlockBorderWrapper"] h3{margin-top:1em}
  div[data-testid="stAlert"]{border-radius:10px}
  hr{border-color:#dbe9f7}
  [data-testid="stSidebar"] hr{border-color:rgba(255,255,255,.18)}
  [data-testid="stSidebar"] [data-testid="stCaptionContainer"],
  [data-testid="stSidebar"] .stCaption{color:#9fc4ea!important}
  [data-testid="stSidebar"] [data-testid="stMarkdownContainer"] p{color:#c9e0f8}
  .stTabs [data-baseweb="tab"] p{color:inherit!important;font-weight:600}
</style>
""", unsafe_allow_html=True)


# ================================================================ MySQL 配置
DEFAULT_DB = {"host": "127.0.0.1", "port": 3306, "user": "root",
              "password": "root", "database": "gangke"}

DDL = [
    """CREATE TABLE IF NOT EXISTS jobs(
        jd_id VARCHAR(64) NOT NULL PRIMARY KEY,
        source VARCHAR(32), title VARCHAR(255), company VARCHAR(255),
        industry VARCHAR(128), company_size VARCHAR(64), property VARCHAR(64),
        city VARCHAR(32), district VARCHAR(64),
        salary_text VARCHAR(64), salary_low FLOAT, salary_high FLOAT, salary_mid FLOAT,
        edu VARCHAR(32), exp VARCHAR(32), job_level TINYINT,
        publish_date VARCHAR(16), skills_raw TEXT, url VARCHAR(512),
        crawl_time DATETIME,
        KEY idx_city (city), KEY idx_pub (publish_date), KEY idx_salary (salary_mid)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
    """CREATE TABLE IF NOT EXISTS crawl_progress(
        city VARCHAR(32) NOT NULL, kw VARCHAR(64) NOT NULL,
        next_page INT NOT NULL DEFAULT 1,
        done TINYINT NOT NULL DEFAULT 0,
        added INT NOT NULL DEFAULT 0,
        updated_at DATETIME,
        PRIMARY KEY(city, kw)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
    """CREATE TABLE IF NOT EXISTS crawl_log(
        id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        ts DATETIME, city VARCHAR(32), kw VARCHAR(64), page INT,
        fetched INT, added INT, note VARCHAR(255)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
]

COLS = ["jd_id", "source", "title", "company", "industry", "company_size", "property",
        "city", "district", "salary_text", "salary_low", "salary_high", "salary_mid",
        "edu", "exp", "job_level", "publish_date", "skills_raw", "url"]


def connect(cfg: dict, with_db: bool = True) -> pymysql.connections.Connection:
    if pymysql is None:
        raise RuntimeError("没装 MySQL 驱动：执行 .venv\\Scripts\\python -m pip install pymysql "
                           "-i https://mirrors.aliyun.com/pypi/simple/ 后刷新页面")
    kw = dict(host=cfg["host"], port=int(cfg["port"]), user=cfg["user"],
              password=cfg["password"], charset="utf8mb4", autocommit=True,
              connect_timeout=6)
    if with_db:
        kw["database"] = cfg["database"]
    return pymysql.connect(**kw)


def init_db(cfg: dict) -> None:
    """库不存在就建，表不存在就建。重复执行无副作用。"""
    cn = connect(cfg, with_db=False)
    try:
        with cn.cursor() as cur:
            cur.execute(f"CREATE DATABASE IF NOT EXISTS `{cfg['database']}` "
                        "DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci")
    finally:
        cn.close()
    cn = connect(cfg)
    try:
        with cn.cursor() as cur:
            for sql in DDL:
                cur.execute(sql)
    finally:
        cn.close()


def query_df(cn, sql: str, args=None) -> pd.DataFrame:
    """pymysql 不是 SQLAlchemy 连接，直接喂 pandas 会告警，这里手工拼。"""
    with cn.cursor() as cur:
        cur.execute(sql, args or ())
        cols = [d[0] for d in cur.description]
        return pd.DataFrame(cur.fetchall(), columns=cols)


def _clean(v):
    """pandas 的 nan / numpy 标量 pymysql 不认，统一转 None 或原生类型。"""
    if v is None or v is pd.NA:
        return None
    if isinstance(v, float) and v != v:
        return None
    if hasattr(v, "item"):
        v = v.item()
        if isinstance(v, float) and v != v:
            return None
    return v


# ================================================================ 断点与写库
def next_page_of(cn, city: str, kw: str) -> tuple[int, int]:
    with cn.cursor() as cur:
        cur.execute("SELECT next_page, done FROM crawl_progress WHERE city=%s AND kw=%s",
                    (city, kw))
        r = cur.fetchone()
    return (r[0], r[1]) if r else (1, 0)


def save_cursor(cn, city: str, kw: str, next_page: int, done: int, added: int) -> None:
    with cn.cursor() as cur:
        cur.execute(
            """INSERT INTO crawl_progress(city,kw,next_page,done,added,updated_at)
               VALUES(%s,%s,%s,%s,%s,%s)
               ON DUPLICATE KEY UPDATE next_page=VALUES(next_page), done=VALUES(done),
                 added=added+VALUES(added), updated_at=VALUES(updated_at)""",
            (city, kw, next_page, done, added, datetime.now()))


def reset_cursor(cn) -> int:
    with cn.cursor() as cur:
        return cur.execute("DELETE FROM crawl_progress")


def save_rows(cn, rows: list[dict]) -> tuple[int, int]:
    """INSERT IGNORE：jd_id 撞了就跳过，重复采集不会产生重复数据。"""
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    vals = []
    for r in rows:
        if not r.get("jd_id") or not r.get("title"):
            continue
        vals.append([_clean(r.get(k)) for k in COLS] + [now])
    if not vals:
        return 0, 0
    ph = ",".join(["%s"] * (len(COLS) + 1))
    sql = f"INSERT IGNORE INTO jobs({','.join(COLS)},crawl_time) VALUES({ph})"
    with cn.cursor() as cur:
        cur.executemany(sql, vals)
        added = max(cur.rowcount, 0)
    return added, len(vals) - added


def write_log(cn, city, kw, page, fetched, added, note) -> None:
    with cn.cursor() as cur:
        cur.execute("INSERT INTO crawl_log(ts,city,kw,page,fetched,added,note) "
                    "VALUES(%s,%s,%s,%s,%s,%s,%s)",
                    (datetime.now(), city, kw, page, fetched, added, str(note)[:255]))


def mirror_rows(sq: sqlite3.Connection, rows: list[dict]) -> int:
    """把刚入库的岗位同步进分析快照（INSERT OR REPLACE，已有则更新）。

    已有 crawl_time 的原样带过来，避免"重建一次全库时间都变成今天"。
    """
    n = 0
    for r in rows:
        if not r.get("jd_id") or not r.get("title"):
            continue
        ts = r.get("crawl_time")
        if hasattr(ts, "strftime"):          # MySQL 取回来是 datetime，转成字符串给 SQLite
            ts = ts.strftime("%Y-%m-%d %H:%M:%S")
        ts = ts or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        vals = [r.get(k) for k in COLS] + [ts]
        sq.execute(
            f"INSERT OR REPLACE INTO jobs({','.join(COLS)},crawl_time) "
            f"VALUES({','.join('?' * 20)})", vals)
        n += 1
    sq.commit()
    return n


def rebuild_mirror(cfg: dict) -> tuple[int, int]:
    """把 MySQL 主库全量灌进分析快照。返回 (同步条数, 快照总条数)。"""
    cn = connect(cfg)
    df = query_df(cn, "SELECT * FROM jobs")
    cn.close()
    sq = ZP.conn()
    n = mirror_rows(sq, df.to_dict("records"))
    total = sq.execute("SELECT COUNT(*) FROM jobs").fetchone()[0]
    sq.close()
    return n, total


# ================================================================ 采集任务
class CrawlJob:
    """后台线程与页面之间的共享状态。线程只写，页面只读。"""

    def __init__(self, cities, kws, pages, delay):
        self.cities, self.kws, self.pages, self.delay = cities, kws, pages, delay
        self.pause = threading.Event()
        self.lock = threading.Lock()
        self.logs: list[str] = []
        self.cur = ("", "", 0)
        self.added = 0
        self.done_tasks = 0
        self.total_tasks = len(cities) * len(kws)
        self.running = True
        self.finished = False
        self.stopped_by_pause = False
        self.error = ""

    def log(self, msg: str) -> None:
        with self.lock:
            self.logs.append(f"{datetime.now():%H:%M:%S}  {msg}")
            del self.logs[:-300]

    def snapshot(self) -> list[str]:
        with self.lock:
            return list(self.logs)

    def nap(self, seconds: float) -> bool:
        """分段睡眠，期间按了暂停能马上醒；返回 True 表示该停了。"""
        end = time.time() + seconds
        while time.time() < end:
            if self.pause.is_set():
                return True
            time.sleep(0.1)
        return self.pause.is_set()


def run_crawl(cfg: dict, job: CrawlJob) -> None:
    """采集主循环：每页开始前查暂停，采完一页同时写 MySQL 和分析快照。"""
    cn = None
    sq = None
    try:
        cn = connect(cfg)
        sq = ZP.conn()
        for city in job.cities:
            jl = ZP.CITY_ZHAOPIN.get(city)
            if not jl:
                job.log(f"[跳过] 没有 {city} 的城市编号")
                continue
            for kw in job.kws:
                start, done = next_page_of(cn, city, kw)
                if done or start > job.pages:
                    job.log(f"[已完成] {city} / {kw} 采到第 {job.pages} 页了，跳过")
                    job.done_tasks += 1
                    continue
                if start > 1:
                    job.log(f"[续采] {city} / {kw} 从第 {start} 页继续")
                for p in range(start, job.pages + 1):
                    if job.pause.is_set():
                        job.stopped_by_pause = True
                        job.log(f"[暂停] 停在 {city} / {kw} 第 {p} 页之前，下次从这一页继续")
                        return
                    job.cur = (city, kw, p)
                    url = f"https://sou.zhaopin.com/?jl={jl}&kw={ZP.quote(kw)}&p={p}"
                    try:
                        rows = ZP.parse_zhaopin(ZP._fetch(url))
                    except Exception as e:
                        job.error = str(e)
                        job.log(f"[中断] {city} / {kw} 第 {p} 页：{e}")
                        job.log("被拦了就先停手。等十分钟或换个网络再点继续，会从这一页接着采。")
                        return
                    if not rows:
                        save_cursor(cn, city, kw, job.pages + 1, 1, 0)
                        write_log(cn, city, kw, p, 0, 0, "空页，判定该词采完")
                        job.log(f"{city} / {kw} 第 {p} 页没有结果，该词标记为采完")
                        break
                    added, dup = save_rows(cn, rows)
                    mirror_rows(sq, rows)
                    last = p >= job.pages
                    save_cursor(cn, city, kw, p + 1, 1 if last else 0, added)
                    write_log(cn, city, kw, p, len(rows), added, f"重复 {dup}")
                    job.added += added
                    job.log(f"{city} / {kw} 第 {p} 页：{len(rows)} 条，新增 {added}，重复 {dup}")
                    if job.nap(job.delay):
                        job.stopped_by_pause = True
                        job.log(f"[暂停] 第 {p} 页已完成，下次从第 {p + 1} 页继续")
                        return
                job.done_tasks += 1
        job.log("[完成] 所有城市和关键词都采完了")
    except Exception as e:
        job.error = str(e)
        job.log(f"[出错] {e}")
    finally:
        for c in (cn, sq):
            if c is not None:
                try:
                    c.close()
                except Exception:
                    pass
        job.running = False
        job.finished = True


def start_job(cfg, cities, kws, pages, delay) -> None:
    job = CrawlJob(cities, kws, pages, delay)
    st.session_state["job"] = job
    threading.Thread(target=run_crawl, args=(cfg, job), daemon=True).start()


# ================================================================ 缓存与分析
def db_ver() -> float:
    return SQLITE_DB.stat().st_mtime if SQLITE_DB.exists() else 0.0


@st.cache_data(show_spinner=False)
def c_overview(v: float) -> dict:
    return A.overview()


@st.cache_data(show_spinner=False)
def c_demand(v: float, k: int = 20) -> pd.DataFrame:
    return A.demand(top_k=k)


@st.cache_data(show_spinner="正在回归技能溢价…")
def c_premium(v: float) -> dict:
    return A.salary_premium(top_n=12, count_floor=25, boot=60)


@st.cache_data(show_spinner=False)
def c_edges(v: float) -> pd.DataFrame:
    return A.pmi_edges(min_n=15, top_k=40)


@st.cache_data(show_spinner=False)
def c_cov(v: float, major: str = "") -> dict:
    return A.coverage(major or None)


def clear_analysis_cache() -> None:
    for f in (c_overview, c_demand, c_premium, c_edges, c_cov):
        f.clear()


def kpi(col, label, value, sub=""):
    col.markdown(f'<div class="kpi"><div class="k">{label}</div><div class="v">{value}</div>'
                 f'<div class="s">{sub}</div></div>', unsafe_allow_html=True)


def sqlite_total() -> int:
    if not SQLITE_DB.exists():
        return 0
    c = sqlite3.connect(SQLITE_DB)
    try:
        return int(c.execute("SELECT COUNT(*) FROM jobs").fetchone()[0])
    except sqlite3.Error:
        return 0
    finally:
        c.close()


# ================================================================ 导出
def write_docx(md: str, major: str) -> Path:
    from docx import Document
    from docx.shared import Pt

    doc = Document()
    doc.styles["Normal"].font.name = "微软雅黑"
    doc.styles["Normal"].font.size = Pt(10.5)
    for line in md.splitlines():
        s = line.strip()
        if not s:
            continue
        if s.startswith("# "):
            doc.add_heading(s[2:], level=0)
        elif s.startswith("## "):
            doc.add_heading(s[3:], level=1)
        elif s.startswith("|"):
            cells = [c.strip() for c in s.strip("|").split("|")]
            if all(set(c) <= set("-: ") for c in cells):
                continue
            doc.add_paragraph(" ｜ ".join(cells))
        elif re.match(r"^\d+\.\s", s) or s.startswith("- "):
            doc.add_paragraph(s.lstrip("- "))
        elif s == "---":
            doc.add_paragraph("")
        else:
            doc.add_paragraph(re.sub(r"\*\*(.+?)\*\*", r"\1", s))
    out = ROOT / "data" / "exports" / f"{major}_诊断报告_{datetime.now():%Y%m%d_%H%M}.docx"
    out.parent.mkdir(parents=True, exist_ok=True)
    doc.save(out)
    return out


def write_ledger(major: str | None = None) -> Path:
    ov = A.overview()
    dem = A.demand(10)
    prem = A.salary_premium(top_n=8, count_floor=25, boot=60)
    cov = A.coverage(major)
    k = SK.kappa_vs_human()
    L = ["# 指标台账（单一事实源）", "",
         "> 规则：对外材料引用的数字只允许出自本文件。改数据后重新生成，不要手改。", ""]
    L += ["## 1 数据规模", "", "| 项 | 值 |", "|---|---|",
          f"| 抓取岗位总数 | {ov.get('total', 0)} 条 |",
          f"| 技术岗（粗筛后） | {ov.get('n', 0)} 条 |",
          f"| 覆盖城市 | {ov.get('cities', 0)} 个 |",
          f"| 招聘企业 | {ov.get('companies', 0)} 家 |",
          f"| 薪资可解析率 | {ov.get('salary_rate', 0):.1%}（{ov.get('salary_ok', 0)} 条） |",
          f"| 月薪中位数 | ¥{ov.get('median', 0):,.0f} |",
          f"| 发布时间范围 | {ov.get('date_min', '-')} ~ {ov.get('date_max', '-')} |",
          f"| 标准技能节点 | {len(SK._DF)} 个 |",
          f"| 技能记录 | {ov.get('skills', 0)} 类 · {int(A.long_table().shape[0])} 条 |", ""]
    if not dem.empty:
        L += ["## 2 需求 Top10", "", "| 技能 | 岗位数 | 占比 | 均薪 |", "|---|---|---|---|"]
        for r in dem.head(10).itertuples():
            L.append(f"| {r.skill} | {r.n} | {r.share:.1%} | ¥{r.sal:,.0f} |")
        L.append("")
    if prem.get("ok"):
        L += ["## 3 薪资溢价（Ridge，控制城市/岗位族/规模/经验/学历/层级）", "",
              f"5 折 CV R² = {prem['r2']:.4f}（无技能基线 {prem.get('r2_base', 0):.4f}），"
              f"样本 {prem['n']} 条。", "",
              "| 技能 | 溢价 | 95% 区间 | 显著 |", "|---|---|---|---|"]
        for r in prem["table"].head(6).itertuples():
            L.append(f"| {r.skill} | {r.premium:+.1%} | [{r.ci_low:+.1%}, {r.ci_high:+.1%}] | "
                     f"{'是' if r.significant else '否'} |")
        L.append("")
    if cov.get("ok"):
        L += ["## 4 课程覆盖", "", "| 项 | 值 |", "|---|---|",
              f"| 专业 | {cov.get('major', '')}（{cov.get('major_code', '')}） |",
              f"| 课程门数 | {cov.get('n_courses', 0)} 门 / {cov.get('n_links', 0)} 条映射 |",
              f"| 加权覆盖率 | {cov['coverage']:.1%} |",
              f"| 红色缺口 | {cov['red']} 项 |", f"| 橙色缺口 | {cov['orange']} 项 |",
              f"| 已覆盖 | {cov['green']} 项 |", ""]
    L += ["## 5 标注抽检", "", "| 项 | 值 |", "|---|---|"]
    if k.get("n"):
        L += [f"| 抽检条数 | {k['n']} |", f"| cell 级一致率 | {k['agree_cells']:.1%} |",
              f"| Cohen's κ | {k['kappa']:.3f} |"]
    else:
        L.append("| 抽检 | 未做 |")
    L.append("")
    out = ROOT / "docs" / "指标台账.md"
    out.write_text("\n".join(L), encoding="utf-8")
    clear_analysis_cache()
    return out


# ================================================================ 采集进度面板
@st.fragment(run_every=2.0)
def panel() -> None:
    j: CrawlJob | None = st.session_state.get("job")
    if not j:
        st.markdown('<div class="blk"><span class="tag idle">空闲</span>'
                    '　还没有开始过。设好城市和关键词，点「开始 / 继续采集」。</div>',
                    unsafe_allow_html=True)
        return
    if j.running:
        tag = '<span class="tag run">采集中</span>'
    elif j.error:
        tag = '<span class="tag warn">已中断</span>'
    elif j.stopped_by_pause:
        tag = '<span class="tag stop">已暂停</span>'
    else:
        tag = '<span class="tag idle">已结束</span>'
    city, kw, p = j.cur
    st.markdown(
        f'<div class="blk">{tag}　当前：<b>{city or "-"}</b> / <b>{kw or "-"}</b>'
        f' / 第 <b>{p or "-"}</b> 页　·　本次新增 <b>{j.added}</b> 条'
        f'　·　任务 {j.done_tasks}/{j.total_tasks}</div>', unsafe_allow_html=True)
    logs = j.snapshot()[-12:]
    if logs:
        st.markdown('<div class="mono">' + "\n".join(logs).replace("<", "&lt;") + "</div>",
                    unsafe_allow_html=True)

    # 采集线程刚停下来时，刷新整页，让看板和统计立刻用上新数据
    if j.finished and not st.session_state.get("_flushed"):
        st.session_state["_flushed"] = id(j)
        clear_analysis_cache()
        st.rerun(scope="app")


# ================================================================ 侧边栏
cfg = st.session_state.get("db_cfg", dict(DEFAULT_DB))
mysql_ok, mysql_err, mysql_n = False, "", 0
try:
    init_db(cfg)
    _cn = connect(cfg)
    with _cn.cursor() as _cur:
        _cur.execute("SELECT COUNT(*) FROM jobs")
        mysql_n = int(_cur.fetchone()[0])
    _cn.close()
    mysql_ok = True
except Exception as e:
    mysql_err = str(e)

ov = c_overview(db_ver())

with st.sidebar:
    st.markdown("### 🎯 职航罗盘")
    st.markdown('<div class="flat">采集 → 入库 → 标注 → 分析 → 诊断报告<br>'
                '</div>', unsafe_allow_html=True)
    st.divider()

    # ---- 专业选择：全站口径的开关
    major_names = MJ.names()
    _default = MJ.default_name()
    major_name = st.selectbox(
        "我的专业", major_names,
        index=major_names.index(_default) if _default in major_names else 0,
        key="major_name",
        help="切换专业后，课程覆盖、学习路径、相关课程、诊断报告全部按该专业口径重算")
    mj = MJ.get(major_name)
    st.markdown(f'<div class="major-chip"><b>{mj["code"]}</b> · {mj["category"]}<br>'
                f'{mj["jobs"]}<br>'
                f'课程 <b>{mj["courses"]}</b> 门（基础 {mj["base"]} / 核心 {mj["core"]} / 拓展 {mj["ext"]}）'
                f'</div>', unsafe_allow_html=True)
    st.caption(f"课程依据：{MJ.source()}")
    st.divider()
    if mysql_ok:
        st.markdown(f'<div class="flat"><b style="color:#1b5e20">MySQL 已连接</b>　'
                    f'{cfg["host"]}:{cfg["port"]}/{cfg["database"]}<br>'
                    f'主库岗位：<b>{mysql_n}</b> 条</div>', unsafe_allow_html=True)
    else:
        st.markdown(f'<div class="flat"><b style="color:#991b1b">MySQL 未连接</b><br>'
                    f'{mysql_err[:90]}</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="flat">分析快照：<b>{sqlite_total()}</b> 条<br>'
                f'技术岗：<b>{ov.get("n", 0)}</b> 条 · 城市 <b>{ov.get("cities", 0)}</b> 个<br>'
                f'标准技能：<b>{len(SK._DF)}</b> 个<br>'
                f'薪资可解析：<b>{ov.get("salary_rate", 0):.0%}</b></div>',
                unsafe_allow_html=True)
    st.divider()
    if st.button("刷新统计", width="stretch"):
        clear_analysis_cache()
        st.rerun()
    #st.caption("主库 MySQL 管采集与断点，分析读本地快照（同一份数据）。")

# ================================================================ 顶部品牌头图
st.markdown(f"""
<div class="hero">
  <div class="brand">职航罗盘 · CAREER COMPASS</div>
  <h1>让每个学生，跟着真实岗位数据规划学业</h1>
  <div class="sub">公开采集智联岗位 × 《职业教育专业教学标准》课程 × 学习路径智能生成
      —— 你选专业，平台算差距，路径直接落到课程与技能。</div>
  <div class="chips">
    <div class="chip">岗位数据 <b>{ov.get("total", 0):,}</b> 条</div>
    <div class="chip">覆盖城市 <b>{ov.get("cities", 0)}</b> 个</div>
    <div class="chip">可选专业 <b>{len(MJ.all_majors())}</b> 个</div>
    <div class="chip">当前专业课程 <b>{mj["courses"]}</b> 门</div>
    <div class="chip">标准技能 <b>{len(SK._DF)}</b> 个</div>
  </div>
</div>
""", unsafe_allow_html=True)
st.caption(f"当前专业：{major_name}（{mj['code']}）　|　课程依据：{MJ.source()}　|　"
           f"所有指标可在「说明与台账」追溯口径，切换专业后全站数字同步重算。")

# ================================================================ 标签页
t1, t2, t3, t4, t5, t6 = st.tabs(
    ["① 采集入库", "② 技能标注", "③ 分析看板", "④ 智能体工作台", "⑤ 学习路径", "⑥ 说明与台账"])

# ---------------------------------------------------------------- ① 采集入库
with t1:
    st.markdown("## 采集入库")
    st.markdown('<div class="flat">智联招聘公开搜索页，免登录直接采。采一页存一页：'
                '数据进 MySQL，断点也进 MySQL，暂停、关页面、关机都不丢进度；'
                '同一岗位重复采到会被主键挡掉，不会重复计数。</div>', unsafe_allow_html=True)
    st.write("")

    with st.expander("数据库连接", expanded=not mysql_ok):
        c = st.columns([1, 0.55, 0.9, 1, 0.9])
        host = c[0].text_input("主机", cfg["host"])
        port = c[1].number_input("端口", 1, 65535, int(cfg["port"]))
        user = c[2].text_input("用户", cfg["user"])
        pwd = c[3].text_input("密码", cfg["password"], type="password")
        dbn = c[4].text_input("库名", cfg["database"])
        if st.button("测试连接并建表"):
            new = {"host": host, "port": int(port), "user": user,
                   "password": pwd, "database": dbn}
            try:
                init_db(new)
                st.session_state["db_cfg"] = new
                st.success(f"连接成功，库 {dbn} 已就绪")
                st.rerun()
            except Exception as e:
                st.error(f"连不上：{e}")

    if not mysql_ok:
        st.error(f"MySQL 没连上：{mysql_err}")
        st.info("展开「数据库连接」填账号密码，点「测试连接并建表」。本机默认 root / root / gangke。"
                "　下面三个分析标签不受影响，仍然读本地快照。")

    m1, m2, m3, m4 = st.columns(4)
    kpi(m1, "MySQL 主库", f"{mysql_n:,}" if mysql_ok else "—", "岗位去重后")
    kpi(m2, "分析快照", f"{sqlite_total():,}", "与主库同源")
    kpi(m3, "技术岗", ov.get("n", 0), "标题粗筛后")
    kpi(m4, "覆盖城市", ov.get("cities", 0), "河南 + 一线城市")

    st.write("")
    zcfg = ZP.load_config()
    st.markdown("### 采集设置")
    a, b, c2 = st.columns([1.2, 1.6, 0.85])
    cities = a.multiselect("城市", list(ZP.CITY_ZHAOPIN.keys()), default=zcfg["cities"])
    kw_text = b.text_input("关键词（逗号分隔）", "，".join(zcfg["keywords"]))
    kws = [k.strip() for k in kw_text.replace("，", ",").split(",") if k.strip()]
    pages = c2.number_input("每个词采到第几页", 1, 10, int(zcfg.get("pages", 2)))
    delay = st.slider("每页之间歇几秒", 1.0, 5.0, 1.8, 0.2)
    st.caption(f"任务数 {len(cities) * len(kws)} 个（城市 × 关键词）。"
               "采过的页按断点跳过；要重头采，点「清空断点」。")

    job: CrawlJob | None = st.session_state.get("job")
    running = bool(job and job.running)

    b1, b2, b3 = st.columns([0.95, 0.85, 1.4])
    start_clicked = b1.button("▶ 开始 / 继续采集", type="primary", width="stretch",
                              disabled=running or not (cities and kws) or not mysql_ok)
    pause_clicked = b2.button("⏸ 暂停采集", width="stretch", disabled=not running)
    reset_clicked = b3.button("清空断点（下次从第 1 页重采）", disabled=not mysql_ok)

    if start_clicked:
        st.session_state.pop("_flushed", None)
        start_job(cfg, cities, kws, int(pages), float(delay))
        st.rerun()
    if pause_clicked and job:
        job.pause.set()
        st.toast("正在停，当前这页采完就停")
    if reset_clicked:
        n = reset_cursor(connect(cfg))
        st.session_state.pop("job", None)
        st.success(f"已清掉 {n} 条断点。数据不会删，重采到的重复记录会被主键挡掉。")

    panel()

    st.divider()
    left, right = st.columns([1.15, 1])
    with left:
        st.markdown("### 断点记录")
        st.caption("「下一页」就是下次要请求的页码。暂停、关页面、关机都不影响。")
        if mysql_ok:
            try:
                pt = query_df(connect(cfg),
                              "SELECT city AS 城市, kw AS 关键词, next_page AS 下一页, "
                              "IF(done=1,'已完成','未完成') AS 状态, added AS 累计新增, "
                              "updated_at AS 更新时间 FROM crawl_progress "
                              "ORDER BY updated_at DESC")
                if pt.empty:
                    st.info("还没有断点记录。")
                else:
                    st.dataframe(pt, width="stretch", hide_index=True, height=250)
            except Exception as e:
                st.warning(f"读断点失败：{e}")
    with right:
        st.markdown("### 两条库对不对得上")
        st.caption("主库是 MySQL，分析快照是本地 SQLite。采集时两边同时写，"
                   "正常情况下条数一致；不一致就用下面的按钮强对齐。")
        d = sqlite_total() - mysql_n
        if d == 0:
            st.success(f"一致：两边都是 {mysql_n} 条")
        else:
            st.warning(f"差 {d:+d} 条（快照 {sqlite_total()} / 主库 {mysql_n}）")
        g1, g2 = st.columns(2)
        if g1.button("MySQL → 分析快照", disabled=not mysql_ok, width="stretch"):
            try:
                n, total = rebuild_mirror(cfg)
                clear_analysis_cache()
                st.success(f"已同步 {n} 条，快照现有 {total} 条")
                st.rerun()
            except Exception as e:
                st.error(f"同步失败：{e}")
        if g2.button("把 SQLite 存量导进 MySQL", disabled=not mysql_ok, width="stretch"):
            try:
                s = sqlite3.connect(SQLITE_DB)
                df = pd.read_sql("SELECT * FROM jobs", s)
                s.close()
                added, dup = save_rows(connect(cfg), df.to_dict("records"))
                st.success(f"导入完成：新增 {added} 条，已存在 {dup} 条")
                st.rerun()
            except Exception as e:
                st.error(f"导入失败：{e}")

    st.markdown("### 最近入库的 200 条")
    try:
        recent = query_df(
            connect(cfg),
            "SELECT title AS 岗位, company AS 公司, city AS 城市, salary_text AS 薪资, "
            "edu AS 学历, exp AS 经验, crawl_time AS 入库时间 FROM jobs "
            "ORDER BY crawl_time DESC LIMIT 200") if mysql_ok else pd.DataFrame()
        if recent.empty:
            st.info("主库还没有数据。选几个城市，点「开始 / 继续采集」。")
        else:
            st.dataframe(recent, width="stretch", height=340, hide_index=True)
            st.download_button("下载全量 CSV",
                               query_df(connect(cfg), "SELECT * FROM jobs")
                               .to_csv(index=False).encode("utf-8-sig"),
                               "岗位库_MySQL.csv", "text/csv")
    except Exception as e:
        st.warning(f"读数据失败：{e}")

# ---------------------------------------------------------------- ② 技能标注
with t2:
    st.markdown("## 技能标注")
    st.markdown('<div class="flat">平台已经给每条岗位打了技能标签，但口径不统一（LLM / 大模型 / AIGC 是三个词）。'
                '这里做两件事：把同义词归到一个标准节点；把平台漏标的从标题里补出来。'
                '认不出来的标签单独存着，交给智能体里的「新词发现」节点。</div>',
                unsafe_allow_html=True)

    a, b = st.columns([1, 2])
    with a:
        if st.button("① 跑技能归一", type="primary"):
            box = st.status("抽取中…", expanded=True)
            SK.run_extract(log=lambda m: box.write(m))
            box.update(label="抽取完成", state="complete")
            clear_analysis_cache()
            st.rerun()
        kval = SK.kappa_vs_human()
        if kval.get("n"):
            st.metric("抽检一致率（cell 级）", f"{kval['agree_cells']:.1%}", f"{kval['n']} 条抽检")
            st.metric("Cohen's κ", f"{kval['kappa']:.3f}")

    with b:
        st.markdown("#### 没认出来的标签（高频在前）")
        un = SK.unknown_tags(min_n=3, limit=25)
        if un.empty:
            st.caption("还没有未识别标签，或还没跑归一。")
        else:
            st.dataframe(un.rename(columns={"tag": "原始标签", "n": "出现次数",
                                            "sample_title": "示例岗位"}),
                         width="stretch", hide_index=True, height=260)
            st.caption(f"这些词出现次数到了门槛，却没进 {len(SK._DF)} 个标准节点。"
                       "补不补进词典，是「数据飞轮」要做的判断。")

    st.divider()
    st.markdown("#### 抽检：系统漏标了多少")
    st.caption("随机抽 8 条，看一眼平台标签和系统归一结果，把漏掉的技能填进去（逗号分隔，没漏就留空）。")
    if st.button("抽取一批样本") or "batch" not in st.session_state:
        con = sqlite3.connect(SQLITE_DB)
        st.session_state["batch"] = pd.read_sql(
            "SELECT jd_id,title,skills_raw FROM jobs ORDER BY RANDOM() LIMIT 8", con)
        con.close()
    batch = st.session_state.get("batch")
    if batch is not None and not batch.empty:
        con = sqlite3.connect(SQLITE_DB)
        rows = []
        for r in batch.itertuples():
            s = pd.read_sql("SELECT skill FROM job_skill WHERE jd_id=?", con, params=(r.jd_id,))
            raw = "、".join(json.loads(r.skills_raw or "[]"))
            rows.append({"岗位": r.title, "平台标签": raw,
                         "系统归一": "、".join(s["skill"].tolist()), "漏标补充": ""})
        con.close()
        ed = st.data_editor(pd.DataFrame(rows), width="stretch", hide_index=True,
                            disabled=["岗位", "平台标签", "系统归一"], key="ed_review")
        if st.button("提交抽检结果"):
            con = sqlite3.connect(SQLITE_DB)
            for i, row in ed.iterrows():
                sysl = [] if not row["系统归一"] else row["系统归一"].split("、")
                extra = [x.strip() for x in re.split(r"[,，、]", str(row["漏标补充"])) if x.strip()]
                human = sorted(set(sysl) | set(extra))
                con.execute("INSERT OR REPLACE INTO review VALUES(?,?,?,?,datetime('now'))",
                            (batch.iloc[i]["jd_id"], json.dumps(human, ensure_ascii=False),
                             json.dumps(sysl, ensure_ascii=False), 0 if extra else 1))
            con.commit()
            con.close()
            st.success("已记录，κ 会更新到左边。")
            st.session_state.pop("batch", None)
            st.rerun()

# ---------------------------------------------------------------- ③ 分析看板
with t3:
    if ov.get("n", 0) == 0:
        st.info("先去 ① 采数据，再到 ② 跑一遍技能归一。")
    else:
        st.markdown("## 分析看板")
        dem = c_demand(db_ver(), 20)
        col1, col2 = st.columns([1.1, 1])
        with col1:
            st.markdown("#### 需求最高的 20 项技能")
            if dem.empty:
                st.info("还没有技能数据。先去 ② 点「跑技能归一」。")
            else:
                st.dataframe(
                    dem.rename(columns={"skill": "技能", "n": "岗位数", "share": "占全部岗位",
                                        "sal": "均薪", "lvl": "平均层级",
                                        "weight": "层级加权需求"}),
                    width="stretch", hide_index=True, height=430,
                    column_config={
                        "岗位数": st.column_config.ProgressColumn(
                            "岗位数", min_value=0, max_value=int(dem["n"].max()), format="%d"),
                        "占全部岗位": st.column_config.NumberColumn(format="%.1%%"),
                        "均薪": st.column_config.NumberColumn(format="¥%d"),
                    })
        with col2:
            st.markdown("#### 技能共现网络")
            st.markdown(f'<div class="fig">{viz.network(c_edges(db_ver()))}</div>',
                        unsafe_allow_html=True)
            st.caption("连在一起的一组技能，就是企业心里一个完整岗位的样子——"
                       "这比单个技能排名更适合拿来划课程模块。")

        st.divider()
        prem = c_premium(db_ver())
        st.markdown("#### 技能值多少钱")
        if prem.get("ok"):
            g1, g2 = st.columns([1.5, 1])
            with g1:
                st.markdown(f'<div class="fig">{viz.premium_bars(prem["table"], 8)}</div>',
                            unsafe_allow_html=True)
            with g2:
                st.caption(f"5 折交叉验证 R²={prem['r2']:.3f}（不含技能的基线 "
                           f"{prem.get('r2_base', 0):.3f}），样本 {prem['n']} 条，"
                           f"控制城市、岗位族、企业规模、经验、学历、岗位层级。"
                           f"技能解释力有限是数据本身的特点，看系数和区间，不看拟合优度。"
                           f"这是关联，不是因果。")
        else:
            st.warning(prem.get("msg"))

        st.divider()
        st.markdown(f"#### 课程覆盖与缺口 · {major_name}")
        cov = c_cov(db_ver(), major_name)
        if cov.get("ok"):
            m = st.columns(4)
            kpi(m[0], "加权覆盖率", f"{cov['coverage']:.1%}", "0.6×需求 + 0.4×溢价")
            kpi(m[1], "红色缺口", cov["red"], "需求高·覆盖≤0.5")
            kpi(m[2], "橙色缺口", cov["orange"], "覆盖不足")
            kpi(m[3], "已覆盖", cov["green"], "覆盖度=1")
            st.markdown(f'<div class="fig">{viz.quadrant(cov["table"])}</div>',
                        unsafe_allow_html=True)
            st.caption(f"🖱️ 鼠标悬浮到圆点上，可查看该技能的覆盖度、需求权重与相关课程名称。"
                       f"本图按 **{major_name}** 的 {cov.get('n_courses', 0)} 门课程、"
                       f"{cov.get('n_links', 0)} 条课程—技能映射计算（{MJ.source()}）。")
        else:
            st.warning(cov.get("msg"))

        st.divider()
        st.markdown("#### 城市与结构")
        cc1, cc2 = st.columns(2)
        with cc1:
            st.dataframe(A.city_profile().rename(columns={"月薪中位": "月薪中位数"}),
                         width="stretch", hide_index=True, height=300)
        with cc2:
            j = A.jobs()
            edu = j["edu"].value_counts().rename_axis("学历").reset_index(name="岗位数")
            exp = j["exp"].value_counts().rename_axis("经验").reset_index(name="岗位数")
            st.dataframe(edu, width="stretch", hide_index=True, height=140)
            st.dataframe(exp, width="stretch", hide_index=True, height=140)

# ---------------------------------------------------------------- ④ 智能体
with t4:
    st.markdown("## 智能体工作台")
    st.markdown('<div class="flat">上面是流程画布，下面是节点配置。每个节点就是一次工具调用，'
                '依赖决定谁先跑。改完自动保存到 config/agent_flow.json。'
                '规则 + 向量 + 可选大模型三条通道，数字仍来自真实查询，报告按当前专业口径生成。</div>',
                unsafe_allow_html=True)

    if "flow" not in st.session_state:
        st.session_state["flow"] = AG.load_flow()
    flow = st.session_state["flow"]

    # ---- 流程画布：独占一整行，不与配置区分栏
    draw = st.empty()
    draw.markdown(f'<div class="fig">{AG.svg(flow, st.session_state.get("status", {}))}</div>',
                  unsafe_allow_html=True)
    st.caption("🔧 工具节点　🚦 校验节点　📄 成稿节点　|　绿色=出结果，红色=没通过，"
               "灰色=被上游跳过，左侧色条表示节点类型")

    left, right = st.columns([1, 1.1])
    with left:
        p1, p2, p3 = st.columns(3)
        p1.text_input("专业（侧边栏切换）", major_name, disabled=True)
        flow["major"] = major_name
        flow["city"] = p2.selectbox("城市", ["全省"] + list(ZP.CITY_ZHAOPIN),
                                    index=0 if flow.get("city", "全省") not in ZP.CITY_ZHAOPIN
                                    else list(ZP.CITY_ZHAOPIN).index(flow["city"]) + 1)
        flow["name"] = p3.text_input("流程名", flow.get("name", "专业适配度诊断"))

        b1, b2 = st.columns([1, 1])
        run_clicked = b1.button("▶ 运行流程", type="primary", width="stretch")
        if b2.button("恢复默认流程", width="stretch"):
            st.session_state["flow"] = json.loads(json.dumps(AG.DEFAULT_FLOW))
            AG.save_flow(st.session_state["flow"])
            st.rerun()

        if run_clicked:
            status = {}
            prog = st.progress(0.0, text="开始")
            total = max(len([n for n in flow["nodes"] if n.get("enabled", True)]), 1)
            done = {"i": 0}

            def on_node(nid, row):
                status[nid] = {"ok": "ok", "未通过": "fail", "报错": "error",
                               "跳过": "skip"}.get(row["状态"], "ok")
                done["i"] += 1
                prog.progress(done["i"] / total,
                              text=f"{row['节点']} · {row['状态']} · {row['耗时ms']}ms")
                draw.markdown(f'<div class="fig">{AG.svg(flow, status)}</div>',
                              unsafe_allow_html=True)

            res = AG.run(flow, {"major": major_name, "city": flow["city"]}, on_node=on_node)
            st.session_state["status"] = status
            st.session_state["last"] = res
            prog.empty()

        res = st.session_state.get("last")
        if res:
            if res["halted"] and not res.get("report"):
                st.warning("流程在校验节点停住了：样本量不够，按规则不出结论。把门槛调低再跑。")
            st.markdown("#### 节点调用记录")
            st.dataframe(pd.DataFrame(res["trace"])[["节点", "工具", "状态", "耗时ms", "摘要"]],
                         width="stretch", hide_index=True, height=280)
            st.caption(f"总耗时 {res['elapsed']} 秒"
                       + ("；流程在校验节点停住了，下游按规则跳过。" if res["halted"] else ""))

    with right:
        st.markdown("#### 节点配置")
        ids = [n["id"] for n in flow["nodes"]]
        for n in flow["nodes"]:
            icon = {"tool": "🔧", "gate": "🚦", "compose": "📄"}.get(n["type"], "🔧")
            with st.expander(f"{icon} {n['title']}", expanded=False):
                n["title"] = st.text_input("名称", n["title"], key=f"ti_{n['id']}")
                tools = list(AG.TOOL_SPEC)
                n["tool"] = st.selectbox(
                    "工具", tools, index=tools.index(n["tool"]) if n["tool"] in tools else 0,
                    key=f"to_{n['id']}")
                spec = AG.TOOL_SPEC[n["tool"]]["args"]
                args = dict(n.get("args") or {})
                cols = st.columns(2)
                for i, (k, dv) in enumerate(spec.items()):
                    if k == "grade":
                        args[k] = cols[i % 2].selectbox(
                            k, ["红", "橙", "绿", "全部"],
                            index=["红", "橙", "绿", "全部"].index(args.get(k, "红")),
                            key=f"ar_{n['id']}_{k}")
                    else:
                        args[k] = cols[i % 2].number_input(k, 1, 5000, int(args.get(k, dv)),
                                                           key=f"ar_{n['id']}_{k}")
                n["args"] = args
                others = [x for x in ids if x != n["id"]]
                n["deps"] = st.multiselect("依赖（先跑完这些才轮到我）", others,
                                           default=[d for d in n.get("deps", []) if d in others],
                                           key=f"dp_{n['id']}")
                n["enabled"] = st.checkbox("启用", n.get("enabled", True), key=f"en_{n['id']}")
                n["type"] = "compose" if n["tool"] == "compose_report" else (
                    "gate" if n["tool"] == "sample_gate" else "tool")
                if st.button("删除这个节点", key=f"del_{n['id']}"):
                    flow["nodes"] = [x for x in flow["nodes"] if x["id"] != n["id"]]
                    for x in flow["nodes"]:
                        x["deps"] = [d for d in x.get("deps", []) if d != n["id"]]
                    AG.save_flow(flow)
                    st.rerun()

        with st.form("add_node", clear_on_submit=True):
            st.markdown("**加一个节点**")
            a1, a2 = st.columns(2)
            new_title = a1.text_input("名称", placeholder="比如：按城市看需求")
            new_tool = a2.selectbox("工具", list(AG.TOOL_SPEC))
            new_deps = st.multiselect("依赖", ids, default=ids[-1:] if ids else [])
            if st.form_submit_button("添加"):
                num = max([int(re.sub(r"\D", "", x) or 0) for x in ids] + [0]) + 1
                flow["nodes"].append({
                    "id": f"n{num}", "type": "tool",
                    "title": new_title or AG.TOOL_SPEC[new_tool]["label"],
                    "tool": new_tool, "args": dict(AG.TOOL_SPEC[new_tool]["args"]),
                    "deps": new_deps, "enabled": True})
                AG.save_flow(flow)
                st.rerun()
        AG.save_flow(flow)

    # ---- 生成的报告：独占一整行，标题+导出按钮一行，正文卡片化
    res = st.session_state.get("last")
    if res and res.get("report"):
        st.divider()
        h1c, h2c = st.columns([3, 1.15])
        with h1c:
            st.markdown("#### 📄 生成的诊断报告")
        with h2c:
            d1, d2 = st.columns(2)
            d1.download_button("下载 Markdown", res["report"].encode("utf-8"),
                               f"{flow['major']}_诊断报告.md", "text/markdown",
                               width="stretch")
            if d2.button("导出 Word", width="stretch"):
                path = write_docx(res["report"], flow["major"])
                st.success(f"已存到 {path}")
        with st.container(border=True):
            st.markdown(res["report"])
            st.caption("本报告由可视化流程自动生成，每个数字都能在上面"
                       "「节点调用记录」里追到来源。")

# ---------------------------------------------------------------- ⑤ 学习路径
with t5:
    st.markdown("## 学习路径")
    st.markdown(f'<div class="flat">当前专业：<b>{major_name}</b>（{mj["code"]}）· 课程依据 {MJ.source()}。'
                f'勾上你已会的技能，选一个目标岗位族，'
                f'马上得到一张按岗位需求排序的补课路线图——每项差距都挂着本专业对应的课程名。'
                f'数据和分析层跟左边看板完全同源，不改口径。</div>',
                unsafe_allow_html=True)
    st.write("")

    lw, rw = st.columns([1, 2.1])
    with lw:
        fam = st.selectbox("目标岗位族", PW.families(), index=1,
                           help="岗位族由职位标题关键词归类，详见分析层 FAMILY_RULES")
        top = st.slider("目标技能取需求榜前", 6, 20, 10)
        have = st.multiselect("我已掌握的技能", PW.all_skills(),
                              default=[], max_selections=30,
                              help="从标准技能词典里勾，勾完点下面的按钮")
        if st.button("生成学习路径", type="primary", width="stretch"):
            with st.spinner("按目标岗位族统计技能需求…"):
                st.session_state["lp_family"] = fam
                st.session_state["lp_major"] = major_name
                st.session_state["lp"] = PW.build_path(have, fam, top, major=major_name)
        #st.caption("💡 赛场演示：请评委随口说三五个会的技能，30 秒出一张个人补课路线。")

    with rw:
        lp = st.session_state.get("lp")
        if lp and lp.get("ok"):
            if lp.get("major") and lp["major"] != major_name:
                st.info(f"下面这张路径是按「{lp['major']}」生成的；你已切换到「{major_name}」，"
                        f"重新点一次「生成学习路径」即可按新专业重算。")
            m = st.columns(3)
            kpi(m[0], "岗位需求命中率", f"{lp['match']:.0%}", "已掌握技能覆盖的需求占比")
            kpi(m[1], "待补技能", len(lp["gap"]), "按岗位要求次数排序")
            kpi(m[2], "本专业课程", mj["courses"], f"{major_name} · 目标 {st.session_state.get('lp_family', '')}")
            st.markdown(f'<div class="fig">{viz.roadmap(lp["gap"], int((lp["table"]["已掌握"]).sum()), lp["match"])}</div>',
                        unsafe_allow_html=True)
            st.markdown("#### 补课清单")
            st.dataframe(lp["gap"], width="stretch", hide_index=True)
            md = PW.to_markdown(have, st.session_state.get("lp_family", fam), lp)
            st.download_button("下载学习路径（Markdown）", md.encode("utf-8"),
                               f"学习路径_{lp.get('major', major_name)}_{st.session_state.get('lp_family', fam)}.md",
                               "text/markdown", width="stretch")
        elif lp:
            st.warning(lp.get("msg", "生成失败"))
        else:
            st.info("左边勾好已会技能、选好岗位族，点「生成学习路径」。")

# ---------------------------------------------------------------- ⑥ 说明与台账
with t6:
    st.markdown("## 数据规范")
    st.markdown("""
**一、数据从哪来，合不合规**

只采招聘网站的公开岗位卡片：职位名、公司名、城市、薪资区间、学历经验要求、平台自己打的技能标签。
不登录、不绕验证码、不进简历库、不碰任何个人信息。每页之间歇 1.8 秒左右，单个来源控制在千条量级。
公司名是公开的企业名，不做二次加工；原始数据只在本机，不对外发布。

**二、为什么采集写 MySQL，分析读本地快照**

采集是"写多、要能断点、要能查流水"的场景，用 MySQL 存：`jobs` 主键去重、`crawl_progress` 记断点、
`crawl_log` 留每次请求的流水。分析是"整表读进 pandas 跑回归和共现"的场景，读本地 SQLite 是毫秒级，
也不占数据库连接。采集时两边同时写，页面上有对照条数和一键强对齐，不会出现两套数字对不上的情况。

**三、AI 用在哪，为什么这样用**

这个项目要回答的"企业要什么技能、值多少钱、课程差在哪"，答案必须是可复算的数字，所以主链路
用规则引擎 + 统计模型，不用大模型出数字。AI 体现在三个互补的语义通道上：
① **向量语义归并**：把平台新标签和词典技能都变成向量，按相似度找出"同一技能的不同写法"
（如「多模态算法」→「多模态」），归并表人工复核后生效、删掉即回退；
② **可选大模型对照**：配好 config/llm.json 后，智能体多一个节点让大模型做同样的映射，
和规则、向量两条通道互相校验；不配置就自动跳过，主流程零影响；
③ **大模型不写库**：LLM 的输出只作对照展示，采纳与否由人决定，避免幻觉污染词典。
断网、没配 key、大模型挂了，项目照样能跑出完整报告——这是刻意设计的工程可靠性。

**四、课程数据：多专业共用一套分析口径**

课程名称与课程组取自教育部《职业教育专业教学标准》的**专业基础课 / 专业核心课 / 专业拓展课**，
逐条建立"课程—技能"映射（1.0 = 独立教学单元，0.5 = 涉及/支撑），每格保留 `evidence_ref` 证据字段。
当前内置 9 个专业（人工智能技术应用、大数据技术、软件技术、计算机网络技术、云计算技术应用、
信息安全技术应用、计算机应用技术、物联网应用技术、数字媒体应用技术），共 145 门课、398 条映射。
学生在侧边栏选专业后，课程覆盖、学习路径、相关课程、诊断报告全部按该专业口径重算——
不同院校、不同专业的学生，看到的是自己专业的缺口与补课清单。

新增专业不用改代码：在 `tools/build_major_courses.py` 里加一个专业块（课程名 + 课程组 + 技能映射），
重跑脚本即可生成 `majors.json`、`courses.csv`、`course_skill_map.csv`。

**五、这套东西给谁用**

给学生个人用：选专业 → 勾已会技能 → 选目标岗位族 → 得到"还差什么、先补哪个、去哪门课补"的路径；
辅导员拿同一份路径做一对一谈话。不做面向教务的管理看板——屏幕上的每个数字，都要能变成学生今天能做的一个动作。
""")

    st.markdown("### 库表")
    st.markdown("""
| 表 | 位置 | 作用 |
|---|---|---|
| `jobs` | MySQL | 岗位主表，`jd_id` 主键，重复采到自动跳过 |
| `crawl_progress` | MySQL | 断点表：城市 × 关键词 → 下一页页码、是否采完 |
| `crawl_log` | MySQL | 请求流水：每次采了几条、新增几条、为什么停 |
| `jobs` / `job_skill` / `tag_pool` / `review` | SQLite `data/jobs.db` | 分析快照：岗位副本、技能记录、未识别标签、抽检 |
| `job_skill` | SQLite | 归一后的技能长表，分析全部从它出发 |
""")

    st.markdown("### 目录")
    st.markdown("""
| 路径 | 作用 |
|---|---|
| `app_all.py` | **本页**：采集入库 + 标注 + 看板 + 智能体 + 学习路径 + 导出，六个标签 |
| `app.py` | 旧的分析版页面（不含 MySQL 采集），保留未动 |
| `app_mysql.py` | 旧的采集版页面（只有采集），保留未动 |
| `core/crawl.py` | 智联采集与薪资解析 |
| `core/skills.py` | 技能归一、未识别标签、抽检 κ（含语义别名表生效逻辑） |
| `core/analyze.py` | 需求、共现、薪资回归、覆盖与缺口 |
| `core/semantic.py` | **语义层**：新词向量归并（transformer/tfidf 双后端）、别名写回 |
| `core/llm.py` | **可选大模型对照**：OpenAI 兼容接口，未配置自动跳过 |
| `core/pathway.py` | **学习路径**：学生画像 → 目标岗位族 → 补课清单（按专业取课程） |
| `core/majors.py` | **专业目录**：专业元数据、课程口径切换 |
| `data/dict/majors.json` | 9 个专业的代码、名称、专业组与课程统计 |
| `data/dict/courses.csv` | 各专业课程清单（课程组、标准来源） |
| `tools/build_major_courses.py` | 多专业课程数据生成脚本（新增专业改这里） |
| `core/agent.py` | 流程引擎 + 流程图渲染（含语义归并/大模型对照节点） |
| `core/viz.py` | 自绘 SVG 图：溢价条形、技能网络、缺口四象限、学习路线图 |
| `config/agent_flow.json` | 智能体流程，页面上改完就存这里 |
| `config/llm.json.example` | 大模型对照配置模板，复制为 llm.json 即启用 |
| `config/crawl.json` | 采集配置（城市、关键词、页数） |
""")

    st.divider()
    st.markdown("### 指标台账")
    #st.caption("所有对外材料（PPT、报告、海报）引用的数字只从这里抄，避免三个地方三个数。")
    if st.button("按当前分析快照重新生成 docs/指标台账.md"):
        path = write_ledger(major_name)
        st.success(f"已更新 {path.relative_to(ROOT)}")
        st.markdown(path.read_text(encoding="utf-8"))
