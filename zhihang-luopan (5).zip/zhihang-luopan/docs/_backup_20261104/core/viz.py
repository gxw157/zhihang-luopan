"""三张自绘 SVG 图：溢价条形、技能网络、缺口四象限。

不用 plotly，一是少装依赖，二是这几张图的样式要跟页面统一。
"""
from __future__ import annotations

import math

import pandas as pd

RED, GREEN, GRAY, INK, MUTED = "#dc2626", "#16a34a", "#94a3b8", "#0f172a", "#64748b"
FONT = "system-ui,-apple-system,Microsoft YaHei"


def _esc(s: str) -> str:
    return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def premium_bars(df: pd.DataFrame, top: int = 8) -> str:
    """技能溢价横向条形图，带 95% 区间。红涨绿跌。"""
    if df is None or df.empty:
        return '<div style="color:#64748b;font-size:13px">没有可用的溢价估计</div>'
    d = df.head(top).iloc[::-1].reset_index(drop=True)
    W, RH, LEFT, RIGHT = 860, 42, 220, 30
    H = 36 + RH * len(d)
    lo = min(d["ci_low"].min(), -0.01)
    hi = max(d["ci_high"].max(), 0.01)
    pad = (hi - lo) * 0.08
    lo, hi = lo - pad, hi + pad

    def x(v):
        return LEFT + (v - lo) / (hi - lo) * (W - LEFT - RIGHT)

    p = [f'<svg viewBox="0 0 {W} {H}" width="100%" style="max-width:{W}px">']
    p.append(f'<line x1="{x(0)}" y1="20" x2="{x(0)}" y2="{H-8}" stroke="#cbd5e1" stroke-width="1"/>')
    p.append(f'<text x="6" y="17" font-size="13" fill="{MUTED}" font-family="{FONT}">控制变量后的月薪差异</text>')
    for i, r in d.iterrows():
        y = 30 + i * RH
        x0, x1 = x(0), x(r["premium"])
        c = RED if r["premium"] >= 0 else GREEN
        p.append(f'<text x="{LEFT-10}" y="{y+15}" text-anchor="end" font-size="15" fill="{INK}" '
                 f'font-family="{FONT}">{_esc(r["skill"])}</text>')
        p.append(f'<rect x="{min(x0,x1)}" y="{y+5}" width="{abs(x1-x0)}" height="19" fill="{c}" opacity="0.85" rx="2"/>')
        p.append(f'<line x1="{x(r["ci_low"])}" y1="{y+14.5}" x2="{x(r["ci_high"])}" y2="{y+14.5}" stroke="{c}" '
                 f'stroke-width="1.4" opacity="0.55"/>')
        p.append(f'<line x1="{x(r["ci_low"])}" y1="{y+8.5}" x2="{x(r["ci_low"])}" y2="{y+20.5}" stroke="{c}" stroke-width="1.4" opacity="0.55"/>')
        p.append(f'<line x1="{x(r["ci_high"])}" y1="{y+8.5}" x2="{x(r["ci_high"])}" y2="{y+20.5}" stroke="{c}" stroke-width="1.4" opacity="0.55"/>')
        # 数值标在区间端点外侧，避免压在条上
        tx, anchor = max(x(r["ci_high"]), x0) + 8, "start"
        if tx > W - 62:
            tx, anchor = min(x(r["ci_low"]), x0) - 8, "end"
        p.append(f'<text x="{tx:.1f}" y="{y+15}" text-anchor="{anchor}" font-size="14" font-weight="600" '
                 f'fill="{c}" font-family="{FONT}">{r["premium"]:+.1%}</text>')
    p.append("</svg>")
    return "".join(p)


def network(edges: pd.DataFrame, top_nodes: int = 14) -> str:
    """技能共现网络：环形布局，边粗 = PMI 高。"""
    if edges is None or edges.empty:
        return '<div style="color:#64748b;font-size:13px">共现数据不足</div>'
    deg = pd.concat([edges["a"], edges["b"]]).value_counts()
    nodes = list(deg.head(top_nodes).index)
    e = edges[edges["a"].isin(nodes) & edges["b"].isin(nodes)]
    W, H, R = 780, 540, 196
    cx, cy = W / 2, H / 2
    pos = {}
    for i, n in enumerate(nodes):
        ang = -math.pi / 2 + 2 * math.pi * i / len(nodes)
        pos[n] = (cx + R * math.cos(ang) * 1.32, cy + R * math.sin(ang))
    mx = max(deg.max(), 1)
    p = [f'<svg viewBox="0 0 {W} {H}" width="100%" style="max-width:{W}px">']
    for r in e.itertuples():
        x1, y1 = pos[r.a]
        x2, y2 = pos[r.b]
        p.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
                 f'stroke="#3b82f6" stroke-width="{0.4 + min(r.pmi,3)*0.9:.1f}" opacity="0.28"/>')
    for n in nodes:
        x, y = pos[n]
        rad = 6 + 8 * (deg[n] / mx) ** 0.6
        p.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{rad:.1f}" fill="#2563eb" opacity="0.9"/>')
        anchor = "middle"
        dx = 0
        if x < cx - 24:
            anchor, dx = "end", -rad - 6
        elif x > cx + 24:
            anchor, dx = "start", rad + 6
        dy = -rad - 6 if abs(y - cy) < 48 and y < cy else rad + 15
        p.append(f'<text x="{x+dx:.1f}" y="{y+dy:.1f}" text-anchor="{anchor}" font-size="14" fill="{INK}" '
                 f'font-family="{FONT}">{_esc(n)}</text>')
    p.append(f'<text x="14" y="{H-12}" font-size="13" fill="{MUTED}" font-family="{FONT}">'
             f'节点大小=出现次数，连线粗细=PMI（只画 PMI&gt;0 且共现≥15 次的边）</text>')
    p.append("</svg>")
    return "".join(p)


def quadrant(df: pd.DataFrame) -> str:
    """横轴课程覆盖度，纵轴需求权重。左上角越靠上越红 = 越该改课。"""
    if df is None or df.empty:
        return '<div style="color:#64748b;font-size:13px">没有覆盖数据</div>'
    d = df.copy()
    d["w"] = d["w"] / max(d["w"].max(), 1e-9)
    W, H, L, B, T, R = 1080, 620, 84, 62, 30, 26

    def X(v):
        return L + float(v) * (W - L - R)

    def Y(v):
        return H - B - float(v) * (H - B - T)

    col = {"红": RED, "橙": "#ea580c", "绿": "#16a34a"}
    p = [f'<svg viewBox="0 0 {W} {H}" width="100%" style="max-width:{W}px">']
    p.append(f'<rect x="{X(0)}" y="{Y(1)}" width="{X(0.5)-X(0)}" height="{Y(0.7)-Y(1)}" fill="#fef2f2"/>')
    p.append(f'<text x="{X(0.02)+6}" y="{Y(1)+26}" font-size="15" font-weight="600" fill="#b91c1c" font-family="{FONT}">'
             f'重点改课区（需求高·覆盖低）</text>')
    for gx in (0, 0.5, 1):
        p.append(f'<line x1="{X(gx)}" y1="{Y(0)}" x2="{X(gx)}" y2="{Y(1)}" stroke="#e2e8f0"/>')
        p.append(f'<text x="{X(gx)}" y="{H-B+24}" text-anchor="middle" font-size="14" fill="{MUTED}" '
                 f'font-family="{FONT}">{gx:.1f}</text>')
    for gy in (0, 0.5, 1):
        p.append(f'<line x1="{X(0)}" y1="{Y(gy)}" x2="{X(1)}" y2="{Y(gy)}" stroke="#e2e8f0"/>')
        p.append(f'<text x="{L-10}" y="{Y(gy)+5}" text-anchor="end" font-size="14" fill="{MUTED}" '
                 f'font-family="{FONT}">{gy:.1f}</text>')
    p.append(f'<text x="{(L+W-R)/2}" y="{H-14}" text-anchor="middle" font-size="16" font-weight="600" fill="{INK}" '
             f'font-family="{FONT}">课程覆盖度</text>')
    p.append(f'<text x="24" y="{(T+H-B)/2}" font-size="16" font-weight="600" fill="{INK}" font-family="{FONT}" '
             f'transform="rotate(-90 24 {(T+H-B)/2})" text-anchor="middle">需求权重（归一）</text>')
    # 只给最靠上的 12 个点打标签，否则十几个标签会叠在一起
    labeled = set(d.sort_values("w", ascending=False).head(12)["skill"])
    for r in d.sort_values("w").itertuples():
        x, y = X(min(r.cover, 1)), Y(min(r.w, 1))
        c = col.get(r.gap_type, GRAY)
        rad = 6 + 5 * math.sqrt(r.n / max(d["n"].max(), 1))
        # 悬浮提示：技能概况 + 相关课程（SVG 原生 <title>，鼠标停留即显示）
        courses = str(getattr(r, "courses", "") or "").strip()
        tip = (f"{r.skill}\n覆盖度 {r.cover:.0%} · 需求权重 {r.w:.2f} · {r.n} 条岗位\n"
               + (f"相关课程：{courses}" if courses else "暂无课程覆盖"))
        p.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{rad:.1f}" fill="{c}" opacity="0.75" '
                 f'stroke="#fff" stroke-width="1.5"><title>{_esc(tip)}</title></circle>')
        if r.skill in labeled:
            p.append(f'<text x="{x+rad+4:.1f}" y="{y+5:.1f}" font-size="14" fill="{INK}" '
                     f'font-family="{FONT}">{_esc(r.skill)}</text>')
    p.append("</svg>")
    return "".join(p)


def roadmap(gap: pd.DataFrame, n_held: int, match: float) -> str:
    """学习路径路线图：已掌握起点 → 按优先级排列的差距技能，箭头串联。

    颜色按课程覆盖度：0 覆盖=红（要先开课）、不满=橙（课程里加深）、已覆盖=绿（自学可到）。
    """
    if gap is None or gap.empty:
        return '<div style="color:#64748b;font-size:13px">没有差距项——目标岗位族的技能都已掌握</div>'
    NW, NH, GX, PAD = 190, 96, 46, 24
    n = len(gap)
    width = PAD * 2 + NW + n * (NW + GX)
    height = PAD * 2 + NH + 46
    y = PAD
    parts = [f'<svg viewBox="0 0 {width} {height}" width="100%" style="max-width:{width}px">',
             '<defs><marker id="rmah" markerWidth="10" markerHeight="10" refX="9" refY="5" orient="auto">'
             '<path d="M0,0 L10,5 L0,10 z" fill="#94a3b8"/></marker></defs>']
    # 起点：已掌握
    parts.append(f'<rect x="{PAD}" y="{y}" width="{NW}" height="{NH}" rx="12" fill="#ecfdf5" '
                 f'stroke="#16a34a" stroke-width="2"/>'
                 f'<text x="{PAD+NW/2}" y="{y+40}" text-anchor="middle" font-size="26" font-weight="700" '
                 f'fill="#15803d" font-family="{FONT}">{n_held}</text>'
                 f'<text x="{PAD+NW/2}" y="{y+68}" text-anchor="middle" font-size="15" fill="#166534" '
                 f'font-family="{FONT}">已掌握技能</text>')
    last_x = PAD + NW
    for r in gap.itertuples():
        cov = float(getattr(r, "_6", 0) or 0)  # "课程覆盖" 列
        c = RED if cov <= 0 else ("#ea580c" if cov < 1 else GREEN)
        fill = "#fef2f2" if cov <= 0 else ("#fff7ed" if cov < 1 else "#f0fdf4")
        x = last_x + GX
        sx = last_x
        parts.append(f'<path d="M{sx},{y+NH/2} L{x-8},{y+NH/2}" fill="none" stroke="#94a3b8" '
                     f'stroke-width="2.4" marker-end="url(#rmah)"/>')
        tip = (f"{getattr(r, '_2', '')}｜{int(getattr(r, '_3', 0))} 条岗位要求｜课程覆盖 {cov:.0%}\n"
                       f"相关课程：{getattr(r, '_7', '') or '暂无'}")
        parts.append(f'<g><rect x="{x}" y="{y}" width="{NW}" height="{NH}" rx="12" fill="{fill}" '
                     f'stroke="{c}" stroke-width="2">'
                     f'<title>{_esc(tip)}</title>'
                     f'<circle cx="{x+22}" cy="{y+22}" r="13" fill="{c}"/>'
                     f'<text x="{x+22}" y="{y+27}" text-anchor="middle" font-size="14" font-weight="700" '
                     f'fill="#fff" font-family="{FONT}">{int(getattr(r, "_1", 0))}</text>'
                     f'<text x="{x+NW/2}" y="{y+52}" text-anchor="middle" font-size="17" font-weight="600" '
                     f'fill="{INK}" font-family="{FONT}">{_esc(str(getattr(r, "_2", ""))[:9])}</text>'
                     f'<text x="{x+NW/2}" y="{y+76}" text-anchor="middle" font-size="12.5" fill="{MUTED}" '
                     f'font-family="{FONT}">{int(getattr(r, "_3", 0))} 条岗位 · 覆盖 {cov:.0%}</text></g>')
        last_x = x + NW
    parts.append(f'<text x="{PAD}" y="{height-10}" font-size="13" fill="{MUTED}" font-family="{FONT}">'
                 f'岗位需求命中率 {match:.0%}　|　红=课程零覆盖需先开课，橙=现有课程加深，绿=已覆盖自学可达　'
                 f'|　悬浮圆点序号即补课顺序</text>')
    parts.append("</svg>")
    return "".join(parts)
