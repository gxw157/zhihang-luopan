"""岗课智配 · 智联采集（MySQL 版）

独立页面，不改动 app.py，也不影响原页面。

它解决三件事：
1. 采集智联招聘公开搜索页，随时可以按「暂停」，不用等这一轮跑完；
2. 每采完一页就把游标写进 MySQL，下次点「继续」从下一页接着采，
   已经采过的页不会再请求一遍；
3. 岗位数据直接落 MySQL，不再写本地 SQLite。

启动：
    .venv\\Scripts\\python -m streamlit run app_mysql.py --server.port 8505

原则和原项目一致：只取公开岗位卡片，不登录、不碰求职者信息，每页之间歇一会儿，
遇到验证页就停下报错，不绕验证码。
"""
from __future__ import annotations

import threading
import time
from datetime import datetime

import pandas as pd
import pymysql
import streamlit as st

from core import crawl as ZP

# ---------------------------------------------------------------- 数据库配置
DEFAULT_DB = {
    "host": "127.0.0.1",
    "port": 3306,
    "user": "root",
    "password": "root",
    "database": "gangke",
}

DDL = [
    """CREATE TABLE IF NOT EXISTS jobs(
        jd_id VARCHAR(64) NOT NULL PRIMARY KEY,
        source VARCHAR(32), title VARCHAR(255), company VARCHAR(255),
        industry VARCHAR(128), company_size VARCHAR(64), property VARCHAR(64),
        city VARCHAR(32), district VARCHAR(64),
        salary_text VARCHAR(64), salary_low FLOAT, salary_high FLOAT, salary_mid FLOAT,
        edu VARCHAR(32), exp VARCHAR(32), job_level TINYINT,
        publish_date VARCHAR(16), skills_raw TEXT, url VARCHAR(512),
        crawl_time DATETIME,
        KEY idx_city (city), KEY idx_pub (publish_date), KEY idx_salary (salary_mid)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
    """CREATE TABLE IF NOT EXISTS crawl_progress(
        city VARCHAR(32) NOT NULL, kw VARCHAR(64) NOT NULL,
        next_page INT NOT NULL DEFAULT 1,
        done TINYINT NOT NULL DEFAULT 0,
        added INT NOT NULL DEFAULT 0,
        updated_at DATETIME,
        PRIMARY KEY(city, kw)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
    """CREATE TABLE IF NOT EXISTS crawl_log(
        id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        ts DATETIME, city VARCHAR(32), kw VARCHAR(64), page INT,
        fetched INT, added INT, note VARCHAR(255)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""",
]

COLS = ["jd_id", "source", "title", "company", "industry", "company_size", "property",
        "city", "district", "salary_text", "salary_low", "salary_high", "salary_mid",
        "edu", "exp", "job_level", "publish_date", "skills_raw", "url"]


def connect(cfg: dict, with_db: bool = True) -> pymysql.connections.Connection:
    kw = dict(host=cfg["host"], port=int(cfg["port"]), user=cfg["user"],
              password=cfg["password"], charset="utf8mb4", autocommit=True,
              connect_timeout=6)
    if with_db:
        kw["database"] = cfg["database"]
    return pymysql.connect(**kw)


def init_db(cfg: dict) -> None:
    """库不存在就建，表不存在就建。重复执行无副作用。"""
    cn = connect(cfg, with_db=False)
    try:
        with cn.cursor() as cur:
            cur.execute(
                f"CREATE DATABASE IF NOT EXISTS `{cfg['database']}` "
                "DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci")
    finally:
        cn.close()
    cn = connect(cfg)
    try:
        with cn.cursor() as cur:
            for sql in DDL:
                cur.execute(sql)
    finally:
        cn.close()


# ---------------------------------------------------------------- 断点游标
def next_page_of(cn, city: str, kw: str) -> tuple[int, int]:
    """返回 (下一页码, 是否已完成)。没有记录就是从第 1 页开始。"""
    with cn.cursor() as cur:
        cur.execute("SELECT next_page, done FROM crawl_progress WHERE city=%s AND kw=%s",
                    (city, kw))
        r = cur.fetchone()
    return (r[0], r[1]) if r else (1, 0)


def save_cursor(cn, city: str, kw: str, next_page: int, done: int, added: int) -> None:
    with cn.cursor() as cur:
        cur.execute(
            """INSERT INTO crawl_progress(city,kw,next_page,done,added,updated_at)
               VALUES(%s,%s,%s,%s,%s,%s)
               ON DUPLICATE KEY UPDATE next_page=VALUES(next_page), done=VALUES(done),
                 added=added+VALUES(added), updated_at=VALUES(updated_at)""",
            (city, kw, next_page, done, added, datetime.now()))


def query_df(cn, sql: str, args=None) -> pd.DataFrame:
    """pymysql 不是 SQLAlchemy 连接，直接喂给 pandas 会告警，这里手工拼。"""
    with cn.cursor() as cur:
        cur.execute(sql, args or ())
        cols = [d[0] for d in cur.description]
        return pd.DataFrame(cur.fetchall(), columns=cols)


def progress_table(cn) -> pd.DataFrame:
    q = ("SELECT city AS 城市, IF(kw='','全部类型',kw) AS 关键词, next_page AS 下一页, "
         "IF(done=1,'已完成','未完成') AS 状态, added AS 累计新增, updated_at AS 更新时间 "
         "FROM crawl_progress ORDER BY updated_at DESC")
    return query_df(cn, q)


def reset_cursor(cn, city: str | None = None, kw: str | None = None) -> int:
    sql, args = "DELETE FROM crawl_progress WHERE 1=1", []
    if city:
        sql += " AND city=%s"
        args.append(city)
    if kw:
        sql += " AND kw=%s"
        args.append(kw)
    with cn.cursor() as cur:
        return cur.execute(sql, args)


def _clean(v):
    """pandas 取出来的 nan / numpy 标量 pymysql 不认，统一转成 None 或原生类型。"""
    if v is None or v is pd.NA:
        return None
    if isinstance(v, float) and v != v:
        return None
    if hasattr(v, "item"):          # numpy.int64 / numpy.float64
        v = v.item()
        if isinstance(v, float) and v != v:
            return None
    return v


# ---------------------------------------------------------------- 写库
def save_rows(cn, rows: list[dict]) -> tuple[int, int]:
    """INSERT IGNORE：jd_id 撞了就跳过，所以重复采集不会产生重复数据。"""
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    vals = []
    for r in rows:
        if not r.get("jd_id") or not r.get("title"):
            continue
        vals.append([_clean(r.get(k)) for k in COLS] + [now])
    if not vals:
        return 0, 0
    ph = ",".join(["%s"] * (len(COLS) + 1))
    sql = f"INSERT IGNORE INTO jobs({','.join(COLS)},crawl_time) VALUES({ph})"
    with cn.cursor() as cur:
        cur.executemany(sql, vals)
        added = max(cur.rowcount, 0)
    return added, len(vals) - added


def write_log(cn, city, kw, page, fetched, added, note) -> None:
    with cn.cursor() as cur:
        cur.execute(
            "INSERT INTO crawl_log(ts,city,kw,page,fetched,added,note) VALUES(%s,%s,%s,%s,%s,%s,%s)",
            (datetime.now(), city, kw, page, fetched, added, note[:255]))


# ---------------------------------------------------------------- 采集任务
class CrawlJob:
    """后台线程和页面之间的共享状态。

    线程只往这里写，页面只读；不去碰 st.session_state（非主线程访问会出问题）。
    """

    def __init__(self, cities, kws, pages, delay):
        self.cities, self.kws, self.pages, self.delay = cities, kws, pages, delay
        self.pause = threading.Event()
        self.lock = threading.Lock()
        self.logs: list[str] = []
        self.cur = ("", "", 0)
        self.added = 0
        self.done_tasks = 0
        self.total_tasks = len(cities) * len(kws)
        self.running = True
        self.finished = False
        self.stopped_by_pause = False
        self.error = ""

    def log(self, msg: str) -> None:
        with self.lock:
            self.logs.append(f"{datetime.now():%H:%M:%S}  {msg}")
            del self.logs[:-300]

    def snapshot(self) -> list[str]:
        with self.lock:
            return list(self.logs)

    def nap(self, seconds: float) -> bool:
        """分段睡眠，期间按了暂停能马上醒；返回 True 表示该停了。"""
        end = time.time() + seconds
        while time.time() < end:
            if self.pause.is_set():
                return True
            time.sleep(0.1)
        return self.pause.is_set()


def run_crawl(cfg: dict, job: CrawlJob) -> None:
    """采集主循环。每页开始前检查暂停标志，采完一页立刻推进游标。"""
    cn = None
    try:
        cn = connect(cfg)
        for city in job.cities:
            jl = ZP.CITY_ZHAOPIN.get(city)
            if not jl:
                job.log(f"[跳过] 没有 {city} 的城市编号")
                continue
            for kw in job.kws:
                start, done = next_page_of(cn, city, kw)
                if done or start > job.pages:
                    job.log(f"[已完成] {city} / {kw or '全部'} 采到第 {job.pages} 页了，跳过")
                    job.done_tasks += 1
                    continue
                if start > 1:
                    job.log(f"[续采] {city} / {kw or '全部'} 从第 {start} 页继续")
                for p in range(start, job.pages + 1):
                    if job.pause.is_set():
                        job.stopped_by_pause = True
                        job.log(f"[暂停] 停在 {city} / {kw or '全部'} 第 {p} 页之前，"
                                f"下次从这一页继续")
                        return
                    job.cur = (city, kw, p)
                    # 留空关键词 = 不限类型，URL 不带 kw 参数，智联会返回该城市全部岗位
                    url = (f"https://sou.zhaopin.com/?jl={jl}&p={p}" if not kw else
                           f"https://sou.zhaopin.com/?jl={jl}&kw={ZP.quote(kw)}&p={p}")
                    try:
                        html = ZP._fetch(url)
                        rows = ZP.parse_zhaopin(html)
                    except Exception as e:
                        job.error = str(e)
                        job.log(f"[中断] {city} / {kw or '全部'} 第 {p} 页：{e}")
                        job.log("被拦了就先停手。等十分钟或换个网络再点继续，会从这一页接着采。")
                        return
                    if not rows:
                        save_cursor(cn, city, kw, job.pages + 1, 1, 0)
                        write_log(cn, city, kw, p, 0, 0, "空页，判定该词采完")
                        job.log(f"{city} / {kw or '全部'} 第 {p} 页没有结果，该词标记为采完")
                        break
                    added, dup = save_rows(cn, rows)
                    last = p >= job.pages
                    save_cursor(cn, city, kw, p + 1, 1 if last else 0, added)
                    write_log(cn, city, kw, p, len(rows), added, f"重复 {dup}")
                    job.added += added
                    job.log(f"{city} / {kw or '全部'} 第 {p} 页：{len(rows)} 条，新增 {added}，重复 {dup}")
                    if job.nap(job.delay):
                        job.stopped_by_pause = True
                        job.log(f"[暂停] 第 {p} 页已完成，下次从第 {p + 1} 页继续")
                        return
                job.done_tasks += 1
        job.log("[完成] 所有城市和关键词都采完了")
    except Exception as e:
        job.error = str(e)
        job.log(f"[出错] {e}")
    finally:
        if cn is not None:
            try:
                cn.close()
            except Exception:
                pass
        job.running = False
        job.finished = True


def start_job(cfg, cities, kws, pages, delay) -> None:
    job = CrawlJob(cities, kws, pages, delay)
    st.session_state["job"] = job
    threading.Thread(target=run_crawl, args=(cfg, job), daemon=True).start()


def import_sqlite(cfg, sqlite_path) -> tuple[int, int]:
    """把原项目 SQLite 里的存量导进 MySQL，省得重新采一遍。"""
    import sqlite3
    s = sqlite3.connect(sqlite_path)
    df = pd.read_sql("SELECT * FROM jobs", s)
    s.close()
    if df.empty:
        return 0, 0
    return save_rows(connect(cfg), df.to_dict("records"))


# ---------------------------------------------------------------- 进度面板
@st.fragment(run_every=1.2)
def panel() -> None:
    j: CrawlJob | None = st.session_state.get("job")
    if not j:
        st.markdown('<div class="blk"><span class="tag idle">空闲</span>'
                    '　还没有开始过。设好城市和关键词，点「开始 / 继续采集」。</div>',
                    unsafe_allow_html=True)
        return
    if j.running:
        tag = '<span class="tag run">采集中</span>'
    elif j.stopped_by_pause:
        tag = '<span class="tag stop">已暂停</span>'
    else:
        tag = '<span class="tag idle">已结束</span>'
    city, kw, p = j.cur
    st.markdown(
        f'<div class="blk">{tag}　当前：<b>{city or "-"}</b> / <b>{kw or "-"}</b>'
        f' / 第 <b>{p or "-"}</b> 页　·　本次新增 <b>{j.added}</b> 条'
        f'　·　任务 {j.done_tasks}/{j.total_tasks}</div>',
        unsafe_allow_html=True)
    logs = j.snapshot()[-12:]
    if logs:
        st.markdown('<div class="mono">' + "\n".join(logs).replace("<", "&lt;") + "</div>",
                    unsafe_allow_html=True)


# ---------------------------------------------------------------- 页面
def main() -> None:
    st.set_page_config(page_title="智联采集 · MySQL", layout="wide")
    st.markdown(
        """
        <style>
        .blk{border:1px solid #e6e8eb;border-radius:8px;padding:12px 14px;background:#fff}
        .mono{font-family:ui-monospace,Consolas,monospace;font-size:12px;line-height:1.7;
              white-space:pre-wrap;color:#333}
        .tag{display:inline-block;padding:2px 9px;border-radius:20px;font-size:12px;font-weight:600}
        .run{background:#e8f5e9;color:#1b5e20}
        .stop{background:#fff3e0;color:#e65100}
        .idle{background:#eceff1;color:#455a64}
        </style>
        """, unsafe_allow_html=True)

    st.markdown("## 智联采集 · MySQL 版")
    st.caption("独立页面，不影响原应用。采一页存一页，暂停后下次接着采，不会重复请求。")

    with st.expander("数据库连接", expanded=False):
        cur_cfg = st.session_state.get("db_cfg", dict(DEFAULT_DB))
        c = st.columns([1, 0.6, 1, 1, 1])
        host = c[0].text_input("主机", cur_cfg["host"])
        port = c[1].number_input("端口", 1, 65535, int(cur_cfg["port"]))
        user = c[2].text_input("用户", cur_cfg["user"])
        pwd = c[3].text_input("密码", cur_cfg["password"], type="password")
        dbn = c[4].text_input("库名", cur_cfg["database"])
        st.session_state["db_cfg"] = {"host": host, "port": int(port), "user": user,
                                      "password": pwd, "database": dbn}
        if st.button("测试连接并建表"):
            try:
                init_db(st.session_state["db_cfg"])
                st.success(f"连接成功，库 {st.session_state['db_cfg']['database']} 已就绪")
            except Exception as e:
                st.error(f"连不上：{e}")

    cfg = st.session_state.get("db_cfg", dict(DEFAULT_DB))
    try:
        init_db(cfg)
        cn0 = connect(cfg)
        with cn0.cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM jobs")
            total_rows = cur.fetchone()[0]
        cn0.close()
    except Exception as e:
        st.error(f"MySQL 没连上：{e}")
        st.info("展开上面的「数据库连接」，填好账号密码，点「测试连接并建表」。"
                "本机默认是 root / root / gangke。")
        st.stop()

    zcfg = ZP.load_config()
    st.markdown("### 采集设置")
    a, b, c2 = st.columns([1.2, 1.6, 0.9])
    cities = a.multiselect("城市", list(ZP.CITY_ZHAOPIN.keys()), default=zcfg["cities"])
    kw_text = b.text_input("关键词（逗号分隔，留空 = 全部类型）", "，".join(zcfg["keywords"]),
                           help="留空表示不限关键词：采集该城市下全部类型的岗位，不再按词拆任务")
    kws = [k.strip() for k in kw_text.replace("，", ",").split(",") if k.strip()] or [""]
    pages = c2.number_input("每个词采到第几页", 1, value=int(zcfg.get("pages", 2)),
                            step=1,
                            help="不限制页数：想采多少页填多少，中途暂停会按页断点续采")
    delay = st.slider("每页之间歇几秒", 1.0, 5.0, 1.8, 0.2)
    if kws == [""]:
        st.caption(f"任务数 {len(cities)} 个（城市 × 全部类型：不限关键词）。"
                   "采过的页会按断点跳过，同一批数据不会重复入库。")
    else:
        st.caption(f"任务数 {len(cities) * len(kws)} 个（城市 × 关键词）。"
                   "采过的页会按断点跳过，同一批数据不会重复入库。")

    job: CrawlJob | None = st.session_state.get("job")
    running = bool(job and job.running)

    b1, b2, b3 = st.columns([0.9, 0.9, 1.3])
    start_clicked = b1.button("▶ 开始 / 继续采集", type="primary",
                              disabled=running or not cities)
    pause_clicked = b2.button("⏸ 暂停采集", disabled=not running)
    if b3.button("清空断点（下次从第 1 页重采）"):
        n = reset_cursor(connect(cfg))
        st.session_state.pop("job", None)
        st.success(f"已清掉 {n} 条断点。数据不会删，重采到的重复记录会被主键挡掉。")
        st.rerun()

    if start_clicked:
        start_job(cfg, cities, kws, int(pages), float(delay))
        st.rerun()
    if pause_clicked and job:
        job.pause.set()
        st.toast("正在停，当前这页采完就停")

    panel()

    st.divider()
    left, right = st.columns([1.15, 1])
    with left:
        st.markdown("### 断点记录")
        st.caption("「下一页」就是下次要请求的页码。暂停、关页面、关机都不影响。")
        try:
            pt = progress_table(connect(cfg))
            if pt.empty:
                st.info("还没有断点记录。")
            else:
                st.dataframe(pt, width="stretch", hide_index=True, height=260)
        except Exception as e:
            st.warning(f"读断点失败：{e}")

    with right:
        st.markdown("### 库里的数据")
        k1, k2 = st.columns(2)
        k1.metric("jobs 总数", f"{total_rows}")
        try:
            cn = connect(cfg)
            city_cnt = int(query_df(cn, "SELECT COUNT(DISTINCT city) c FROM jobs")["c"][0])
            salary_cnt = int(query_df(
                cn, "SELECT COUNT(*) c FROM jobs WHERE salary_mid IS NOT NULL")["c"][0])
            cn.close()
            k2.metric("覆盖城市", f"{city_cnt}")
            st.caption(f"其中 {salary_cnt} 条能解析出月薪（{salary_cnt / max(total_rows, 1):.0%}）")
        except Exception:
            pass
        if st.button("把原 SQLite 库的存量导进来"):
            try:
                from pathlib import Path
                added, dup = import_sqlite(cfg, Path(__file__).resolve().parent / "data" / "jobs.db")
                st.success(f"导入完成：新增 {added} 条，已存在跳过 {dup} 条")
                st.rerun()
            except Exception as e:
                st.error(f"导入失败：{e}")

    st.markdown("### 最近入库的 200 条")
    try:
        recent = query_df(
            connect(cfg),
            "SELECT title AS 岗位, company AS 公司, city AS 城市, salary_text AS 薪资, "
            "edu AS 学历, exp AS 经验, crawl_time AS 入库时间 "
            "FROM jobs ORDER BY crawl_time DESC LIMIT 200")
        st.dataframe(recent, width="stretch", height=360, hide_index=True)
    except Exception as e:
        st.warning(f"读数据失败：{e}")

    st.caption("只采公开岗位卡片，不登录、不碰求职者信息。被拦时程序会停下，不会去绕验证码。")


if __name__ == "__main__":
    main()
