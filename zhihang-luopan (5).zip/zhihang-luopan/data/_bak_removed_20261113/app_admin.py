"""职航罗盘 · 工程后台（独立入口，方案 C 物理隔离）

学生端 app_all.py 不含任何后台能力；采集引擎、MySQL 直连、账号台账全部在本入口：
    双击 启动_工程后台.bat
    或  .venv\\Scripts\\python -m streamlit run app_admin.py --server.port 8521

鉴权：账号密码登录，且账号必须在 config/admin.json 的 admins 名单内。
换电脑/换浏览器，用 ?t=<token> 恢复登录（token 由登录成功后生成）。
"""
from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from core import auth as AU  # noqa: E402
from core.admin_ui import (  # noqa: E402
    is_admin,
    mysql_status,
    render_admin_screen,
    sqlite_total,
)
from core.theme import THEME_CSS  # noqa: E402

st.set_page_config(page_title="职航罗盘 · 工程后台", page_icon="🛠",
                   layout="wide", initial_sidebar_state="expanded")
st.markdown(THEME_CSS, unsafe_allow_html=True)


def _logout() -> None:
    tok = st.session_state.get("admin_token")
    if tok:
        AU.drop_session(tok)
    st.session_state.pop("admin_token", None)


# ================================================================ 登录态
_token = st.query_params.get("t") or st.session_state.get("admin_token")
_user = AU.user_by_token(str(_token)) if _token else None
if _user and not is_admin(_user.get("account", "")):
    _user = None      # 名单外的账号即使有有效会话也不放行

if not _user:
    st.markdown('<div class="hero"><div class="brand">职航罗盘 · 工程后台</div>'
                '<h1>开发者入口</h1></div>', unsafe_allow_html=True)
    with st.form("admin_login"):
        acc = st.text_input("登录账号", key="admin_acc",
                            placeholder="手机号或自定义账号")
        pw = st.text_input("密码", key="admin_pw", type="password")
        ok = st.form_submit_button("登 录", type="primary", width="stretch",
                                   key="admin_login_btn")
    if ok:
        r = AU.login_with_password(acc.strip(), pw)
        if not r.get("ok"):
            st.error(r.get("msg", "登录失败"))
        elif not is_admin(r["user"]["account"]):
            st.error("该账号不在开发者名单（config/admin.json 的 admins）里，"
                     "无权进入工程后台。")
        else:
            st.session_state["admin_token"] = AU.create_session(int(r["user"]["id"]))
            st.rerun()
    st.stop()

# ================================================================ 已登录：侧栏
with st.sidebar:
    st.markdown("### 职航罗盘 · 工程后台")
    st.markdown(f'<div class="acct"><div class="nm">{_user.get("nickname") or "开发者"}</div>'
                f'<div class="ph">{_user.get("account_masked", "")} · 开发者</div></div>',
                unsafe_allow_html=True)
    st.button("退出登录", key="admin_logout", width="stretch", on_click=_logout)
    st.divider()
    my = mysql_status()
    if my["ok"]:
        st.markdown(f'<div class="flat"><b style="color:#1b5e20">MySQL 已连接</b>　'
                    f'{my["cfg"]["host"]}:{my["cfg"]["port"]}/{my["cfg"]["database"]}<br>'
                    f'主库岗位：<b>{my["n"]}</b> 条</div>', unsafe_allow_html=True)
    else:
        st.markdown(f'<div class="flat"><b style="color:#991b1b">MySQL 未连接</b><br>'
                    f'{my["err"][:90]}</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="flat">分析快照：<b>{sqlite_total()}</b> 条（data/jobs.db）</div>',
                unsafe_allow_html=True)

# ================================================================ 已登录：后台主体
st.markdown('<div class="hero"><div class="brand">职航罗盘 · 工程后台</div>'
            '<h1>采集入库 · 技能标注 · 数据规范 · 账号台账</h1></div>',
            unsafe_allow_html=True)
render_admin_screen(int(_user["id"]), _user)
st.markdown('<div class="page-foot">职航罗盘 · 工程后台（独立入口，与用户端分离）</div>',
            unsafe_allow_html=True)
