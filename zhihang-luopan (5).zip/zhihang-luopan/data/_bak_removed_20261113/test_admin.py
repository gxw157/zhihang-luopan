# -*- coding: utf-8 -*-
"""工程后台独立入口（app_admin.py）冒烟测试：

1. 开发者名单加载与 is_admin 判定；
2. 未登录：只有登录表单，不见后台内容；
3. 名单外账号（有密码）登录被拒；
4. 名单内账号登录 → 四个 tab 全部渲染；
5. 学生端 app_all.py 不含后台元素（无采集按钮 / 账号台账）。
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from _demo_login import login_demo  # noqa: E402

from streamlit.testing.v1 import AppTest  # noqa: E402

from core.admin_ui import is_admin, load_admins  # noqa: E402

PROBLEMS: list[str] = []


def ok(m: str) -> None:
    print("  ✅", m)


def bad(m: str) -> None:
    PROBLEMS.append(m)
    print("  ❌", m)


def step(m: str) -> None:
    print(f"\n— {m}")


def nav_opts(at):
    """安全取导航 radio 的 options（未登录时不存在，返回空表）。"""
    try:
        r = at.radio(key="screen")
        return list(r.options) if r else []
    except KeyError:
        return []


step("1. 开发者名单（config/admin.json）")
admins = load_admins()
if not admins:
    bad("admins 名单为空，谁也进不了后台")
else:
    ok(f"admins = {admins}")
if admins and is_admin(admins[0]):
    ok("名单内账号 is_admin=True")
else:
    bad("is_admin 对名单内账号返回 False")
if is_admin("99999999999"):
    bad("名单外账号 is_admin=True（闸门失效）")
else:
    ok("名单外账号 is_admin=False")

step("2. 未登录：只有登录表单")
at = AppTest.from_file(str(ROOT / "app_admin.py"), default_timeout=60)
at.run()
if at.exception:
    bad(f"未登录页异常：{at.exception}")
else:
    ok("未登录页渲染无异常")
if at.form(key="admin_login"):
    ok("登录表单存在")
else:
    bad("找不到登录表单 admin_login")
if any("工程后台" in (h.value or "") for h in at.markdown):
    ok("入口页提示「工程后台」")
else:
    bad("入口页缺少工程后台标识")

step("3. 名单外账号登录被拒（演示二号有密码但不在名单）")
at.text_input(key="admin_acc").set_value("13800000002")
at.text_input(key="admin_pw").set_value("demo123456")
at.button(key="admin_login_btn").click().run()
errs = [e.value for e in at.exception] or []
msgs = [x.value for x in getattr(at, "error", [])]
if any("开发者名单" in m for m in msgs):
    ok("名单外账号被拒（提示无权进入）")
else:
    bad(f"名单外账号未被正确拒绝：msgs={msgs} errs={errs}")
if at.session_state.get("admin_token"):
    bad("被拒账号却拿到了 admin_token")
else:
    ok("被拒账号未产生会话")

step("4. 名单内账号登录 → 四个 tab 渲染")
at.text_input(key="admin_acc").set_value(admins[0])
at.text_input(key="admin_pw").set_value("demo123456")
at.button(key="admin_login_btn").click().run()
if at.session_state.get("admin_token"):
    ok("登录成功，admin_token 已写入")
else:
    bad("名单内账号登录失败")
tabs = [t.label for t in at.tabs]
if set(tabs) == {"采集入库", "技能标注", "数据规范与台账", "账号与登录"}:
    ok(f"后台四 tab 齐全：{tabs}")
else:
    bad(f"后台 tab 异常：{tabs}")
if at.exception:
    bad(f"后台渲染异常：{at.exception}")
else:
    ok("后台整页渲染无异常")
# 采集入库区应有「开始 / 继续采集」按钮
if any("开始 / 继续采集" in (b.label or "") for b in at.button):
    ok("采集引擎已挂载（开始按钮存在）")
else:
    bad("采集入库缺少开始按钮")
# 退出按钮存在
if any((b.key or "") == "admin_logout" for b in at.button):
    ok("退出按钮存在")
else:
    bad("缺少退出按钮")

step("5. 学生端（名单外演示二号）登录 → 只有学生端七屏")
st2 = AppTest.from_file(str(ROOT / "app_all.py"), default_timeout=60)
st2.run()
# 用演示二号（不在 admins 名单）进入学生端
login_demo(st2, 1)
if st2.session_state.get("user"):
    keys = [(b.key or "") for b in st2.button]
    if any(k.startswith("crawl_") for k in keys):
        bad("学生端残留采集按钮")
    else:
        ok("学生端无采集按钮")
    opts = st2.radio(key="screen").options if st2.radio(key="screen") else []
    if any("⑧" in o for o in opts):
        bad("学生账号导航残留 ⑧（身份闸门失效）")
    else:
        ok(f"学生账号导航 {len(opts)} 屏，无工程后台")
    if any((b.key or "") == "dev_go" for b in st2.button):
        bad("登录后的工作台不应再有开发者入口")
    else:
        ok("登录后无开发者入口（入口只在未登录首页）")
else:
    bad("学生端演示二号登录失败（前置步骤未过，本步判定为失败）")

step("5b. 未登录首页：开发者入口 popover；名单外被拒、名单内登入")
st3 = AppTest.from_file(str(ROOT / "app_all.py"), default_timeout=60)
st3.run()
go3 = next((b for b in st3.button if (b.key or "") == "dev_go"), None)
acc3 = next((t for t in st3.text_input if (t.key or "") == "dev_acc"), None)
if go3 and acc3:
    ok("未登录首页存在「开发者入口」登录表单")
    # 名单外账号：被拒且不进入
    st3.text_input(key="dev_acc").set_value("13800000002")
    st3.text_input(key="dev_pw").set_value("demo123456")
    st3.button(key="dev_go").click().run()
    msgs = [x.value for x in getattr(st3, "error", [])]
    if any("开发者名单" in m for m in msgs):
        ok("名单外账号经入口登录被拒")
    else:
        bad(f"名单外账号未被拒：msgs={msgs}")
    if nav_opts(st3):
        bad("被拒账号却进入了工作台")
    else:
        ok("被拒账号仍停留在首页")
    # 名单内账号：进入 → 自动带 ⑧
    st3.text_input(key="dev_acc").set_value(admins[0])
    st3.text_input(key="dev_pw").set_value("demo123456")
    st3.button(key="dev_go").click().run()
    opts = nav_opts(st3)
    if any("⑧" in o for o in opts):
        ok(f"名单内账号经入口登录 → 开发者视图（{len(opts)} 屏含 ⑧）")
    else:
        bad(f"名单内账号登录后导航异常：{opts}")
else:
    bad("未登录首页缺少开发者入口（dev_acc/dev_go 不存在）")

step("6. 开发者视图：⑧ 渲染后台四 tab；普通登录卡的开发者账号同样自动带 ⑧")
if any("⑧" in o for o in nav_opts(st3)):
    st3.radio(key="screen").set_value("⑧ 工程后台").run()
    tabs = [t.label for t in st3.tabs]
    if set(tabs) == {"采集入库", "技能标注", "数据规范与台账", "账号与登录"}:
        ok("开发者视图内后台四 tab 渲染正常")
    else:
        bad(f"开发者视图后台 tab 异常：{tabs}")
    if st3.exception:
        bad(f"⑧ 渲染异常：{st3.exception}")
else:
    bad("5b 未进入开发者视图，本步跳过")

# 普通登录卡路径：名单内账号走「登录」卡也自动获得开发者视图
st4 = AppTest.from_file(str(ROOT / "app_all.py"), default_timeout=60)
st4.run()
st4.text_input(key="lg_phone").set_value(admins[0])
st4.text_input(key="lg_pwd").set_value("demo123456")
st4.button(key="lg_do").click().run()
opts4 = nav_opts(st4)
if any("⑧" in o for o in opts4):
    ok(f"开发者账号经普通登录卡登录同样自动进入开发者视图（{len(opts4)} 屏）")
else:
    bad(f"普通登录卡的开发者账号没拿到 ⑧：{opts4}")
opts5 = nav_opts(st2)
if opts5 and not any("⑧" in o for o in opts5):
    ok("（对照）学生账号经普通登录卡仍只有七屏")
elif opts5:
    bad("学生账号经普通登录卡出现了 ⑧")

print("\n" + "=" * 70)
if PROBLEMS:
    print(f"❌ 发现 {len(PROBLEMS)} 个问题：")
    print("\n".join(PROBLEMS))
    sys.exit(1)
print("🎉 工程后台冒烟测试全部通过")
