"""岗课智配 2.0 · 招聘数据 → 技能需求 → 课程诊断

启动：  双击 启动.bat    或    python -m streamlit run app.py
五个页面，全部在浏览器里点，不用改代码。
"""
from __future__ import annotations

import json
import re
import sqlite3
import sys
from pathlib import Path

import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from core import agent as AG  # noqa: E402
from core import analyze as A  # noqa: E402
from core import crawl  # noqa: E402
from core import skills as SK  # noqa: E402
from core import viz  # noqa: E402

DB = ROOT / "data" / "jobs.db"

st.set_page_config(page_title="岗课智配 · 招聘数据驱动的专业诊断", page_icon="🎯",
                   layout="wide", initial_sidebar_state="expanded")

st.markdown("""
<style>
  .block-container{padding-top:2.2rem;max-width:1500px}
  h1,h2,h3{letter-spacing:0}
  .kpi{background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:12px 14px;height:100%}
  .kpi .k{font-size:12px;color:#64748b}
  .kpi .v{font-size:24px;font-weight:700;color:#0f172a;line-height:1.35}
  .kpi .s{font-size:11.5px;color:#94a3b8}
  .note{background:#fffbeb;border-left:3px solid #f59e0b;padding:10px 14px;border-radius:0 6px 6px 0;
        font-size:13px;color:#78350f;line-height:1.7}
  .flat{color:#64748b;font-size:13px;line-height:1.8}
  div[data-testid="stExpander"] summary{font-size:13.5px}
</style>
""", unsafe_allow_html=True)


# ---------------------------------------------------------------- 缓存
def db_ver() -> float:
    return DB.stat().st_mtime if DB.exists() else 0.0


@st.cache_data(show_spinner=False)
def c_overview(v: float) -> dict:
    return A.overview()


@st.cache_data(show_spinner=False)
def c_demand(v: float, k: int = 20, city: str = "全省") -> pd.DataFrame:
    return A.demand(top_k=k, city=city)


@st.cache_data(show_spinner="正在回归技能溢价…")
def c_premium(v: float) -> dict:
    return A.salary_premium(top_n=12, count_floor=25, boot=60)


@st.cache_data(show_spinner=False)
def c_edges(v: float) -> pd.DataFrame:
    return A.pmi_edges(min_n=15, top_k=40)


@st.cache_data(show_spinner=False)
def c_cov(v: float) -> dict:
    return A.coverage()


def kpi(col, label, value, sub=""):
    col.markdown(f'<div class="kpi"><div class="k">{label}</div><div class="v">{value}</div>'
                 f'<div class="s">{sub}</div></div>', unsafe_allow_html=True)


# ---------------------------------------------------------------- 侧边栏
ov = c_overview(db_ver())
with st.sidebar:
    st.markdown("### 🎯 岗课智配")
    st.markdown('<div class="flat">招聘数据 → 技能需求 → 课程诊断<br></div>',
                unsafe_allow_html=True)
    st.divider()
    st.divider()
    st.markdown(f'<div class="flat">岗位库：<b>{ov.get("n", 0)}</b> 条（技术岗）<br>'
                f'抓取总数：<b>{ov.get("total", 0)}</b> 条 · 城市 <b>{ov.get("cities", 0)}</b> 个<br>'
                f'标准技能：<b>{len(SK._DF)}</b> 个 · 薪资可解析 <b>{ov.get("salary_rate", 0):.0%}</b></div>',
                unsafe_allow_html=True)
    st.divider()
    #st.caption("没有数据就先跑第 ① 页；赛前建议采到 800 条以上。")

# ---------------------------------------------------------------- 导出 Word
def write_docx(md: str, major: str) -> Path:
    from docx import Document
    from docx.shared import Pt
    from datetime import datetime

    doc = Document()
    doc.styles["Normal"].font.name = "微软雅黑"
    doc.styles["Normal"].font.size = Pt(10.5)
    for line in md.splitlines():
        s = line.strip()
        if not s:
            continue
        if s.startswith("# "):
            doc.add_heading(s[2:], level=0)
        elif s.startswith("## "):
            doc.add_heading(s[3:], level=1)
        elif s.startswith("|"):
            cells = [c.strip() for c in s.strip("|").split("|")]
            if all(set(c) <= set("-: ") for c in cells):
                continue
            doc.add_paragraph(" ｜ ".join(cells))
        elif re.match(r"^\d+\.\s", s) or s.startswith("- "):
            doc.add_paragraph(s.lstrip("- "))
        elif s == "---":
            doc.add_paragraph("")
        else:
            doc.add_paragraph(re.sub(r"\*\*(.+?)\*\*", r"\1", s))
    out = ROOT / "data" / "exports" / f"{major}_诊断报告_{datetime.now():%Y%m%d_%H%M}.docx"
    out.parent.mkdir(parents=True, exist_ok=True)
    doc.save(out)
    return out


def write_ledger() -> Path:
    ov = A.overview()
    dem = A.demand(10)
    prem = A.salary_premium(top_n=8, count_floor=25, boot=60)
    cov = A.coverage()
    k = SK.kappa_vs_human()
    L = ["# 指标台账（单一事实源）", ""]
    L += ["## 1 数据规模", "", "| 项 | 值 |", "|---|---|",
          f"| 抓取岗位总数 | {ov.get('total', 0)} 条 |",
          f"| 技术岗（粗筛后） | {ov.get('n', 0)} 条 |",
          f"| 覆盖城市 | {ov.get('cities', 0)} 个 |",
          f"| 招聘企业 | {ov.get('companies', 0)} 家 |",
          f"| 薪资可解析率 | {ov.get('salary_rate', 0):.1%}（{ov.get('salary_ok', 0)} 条） |",
          f"| 月薪中位数 | ¥{ov.get('median', 0):,.0f} |",
          f"| 发布时间范围 | {ov.get('date_min', '-')} ~ {ov.get('date_max', '-')} |",
          f"| 标准技能节点 | {len(SK._DF)} 个 |",
          f"| 技能记录 | {ov.get('skills', 0)} 类 · {int(A.long_table().shape[0])} 条 |", ""]
    if not dem.empty:
        L += ["## 2 需求 Top10", "", "| 技能 | 岗位数 | 占比 | 均薪 |", "|---|---|---|---|"]
        for r in dem.head(10).itertuples():
            L.append(f"| {r.skill} | {r.n} | {r.share:.1%} | ¥{r.sal:,.0f} |")
        L.append("")
    if prem.get("ok"):
        L += ["## 3 薪资溢价（Ridge，控制城市/岗位族/规模/经验/学历/层级）", "",
              f"5 折 CV R² = {prem['r2']:.4f}（无技能基线 {prem.get('r2_base', 0):.4f}），样本 {prem['n']} 条。", "",
              "| 技能 | 溢价 | 95% 区间 | 显著 |", "|---|---|---|---|"]
        for r in prem["table"].head(6).itertuples():
            L.append(f"| {r.skill} | {r.premium:+.1%} | [{r.ci_low:+.1%}, {r.ci_high:+.1%}] | "
                     f"{'是' if r.significant else '否'} |")
        L.append("")
    if cov.get("ok"):
        L += ["## 4 课程覆盖", "", "| 项 | 值 |", "|---|---|",
              f"| 加权覆盖率 | {cov['coverage']:.1%} |",
              f"| 红色缺口 | {cov['red']} 项 |", f"| 橙色缺口 | {cov['orange']} 项 |",
              f"| 已覆盖 | {cov['green']} 项 |", ""]
    L += ["## 5 标注抽检", "", "| 项 | 值 |", "|---|---|"]
    if k.get("n"):
        L += [f"| 抽检条数 | {k['n']} |", f"| cell 级一致率 | {k['agree_cells']:.1%} |",
              f"| Cohen's κ | {k['kappa']:.3f} |"]
    else:
        L.append("| 抽检 | 未做 |")
    L.append("")
    out = ROOT / "docs" / "指标台账.md"
    out.write_text("\n".join(L), encoding="utf-8")
    c_overview.clear()
    return out


t1, t2, t3, t4, t5 = st.tabs(["① 数据", "② 技能标注", "③ 分析看板", "④ 智能体工作台", "⑤ 说明"])

# ================================================================ ① 数据
with t1:
    st.markdown("## 岗位数据")
    st.markdown('<div class="flat">数据来源：智联招聘公开搜索页，免登录直接采。'
                '只取公开的岗位卡片信息，不碰任何求职者信息。</div>',
                unsafe_allow_html=True)
    st.write("")
    c = st.columns(5)
    kpi(c[0], "岗位总数", ov.get("n", 0), "去重后")
    kpi(c[1], "覆盖城市", ov.get("cities", 0), "河南 + 一线城市")
    kpi(c[2], "招聘企业", ov.get("companies", 0), "去重")
    kpi(c[3], "月薪中位数", f"¥{ov.get('median', 0):,.0f}", "折 12 个月")
    kpi(c[4], "时间范围", f"{ov.get('date_min', '-')[:7]}", f"至 {ov.get('date_max', '-')[:7]}")

    st.write("")
    left, right = st.columns([1.05, 1])
    with left:
        st.markdown("### 采集智联招聘")
        cfg = crawl.load_config()
        cities = st.multiselect("城市", list(crawl.CITY_ZHAOPIN.keys()), default=cfg["cities"])
        kw_text = st.text_input("关键词（逗号分隔）", "，".join(cfg["keywords"]))
        kws = [k.strip() for k in re.split(r"[,，]", kw_text) if k.strip()]
        pages = st.slider("每个关键词翻几页（每页 20 条）", 1, 5, int(cfg.get("pages", 2)))
        st.caption(f"预计请求 {len(cities) * len(kws) * pages} 次，每次间隔约 2 秒，"
                   f"大约 {len(cities) * len(kws) * pages * 2 // 60 + 1} 分钟。")
        if st.button("开始采集", type="primary", disabled=not (cities and kws)):
            box = st.status("采集中…", expanded=True)
            stat = crawl.crawl_zhaopin(cities, kws, pages, log=lambda m: box.write(m))
            box.update(label=f"完成：新增 {stat['新入库']} 条，重复 {stat['重复']} 条", state="complete")
            c_overview.clear()
            st.rerun()

    with right:
        st.markdown("### 采集规范")
        st.markdown('<div class="note">'
                    '① 只采公开搜索页，不登录、不碰简历；<br>'
                    '② 每次请求间隔约 2 秒，一页 20 条，慢一点不容易被拦；<br>'
                    '③ 城市编号在 <code>core/crawl.py</code> 的 CITY_ZHAOPIN 里，'
                    '加城市就加一行；<br>'
                    '④ 采完要去「② 技能标注」跑一遍归一，后面的分析才有数可用。</div>',
                    unsafe_allow_html=True)
        st.write("")
        st.markdown("### 可能碰到的两个坑")
        st.markdown('<div class="note">'
                    '<b>验证页</b>：智联会识别脚本请求。程序先试系统 curl，再退回 requests，'
                    '都不行就报错停下——不绕验证码。等十分钟或换网络再采。<br><br>'
                    '<b>无关岗位</b>：搜"数据分析"会带出销售、会计。分析阶段按标题做技术岗粗筛，'
                    '所以库里的总数和参与分析的数量不一样，页面上两个数都标了。</div>',
                    unsafe_allow_html=True)

    
    st.divider()
    
    st.markdown("### 库里的数据")
    if ov.get("n", 0) > 0:
        con = sqlite3.connect(DB)
        df = pd.read_sql("SELECT jd_id,source,title,company,city,salary_text,salary_mid,edu,exp,"
                         "publish_date,skills_raw FROM jobs ORDER BY crawl_time DESC LIMIT 400", con)
        con.close()
        st.dataframe(df, width="stretch", height=340, hide_index=True)
        st.download_button("下载全量 CSV", df.to_csv(index=False).encode("utf-8-sig"),
                           "岗位库.csv", "text/csv")
    else:
        st.info("库里还没有数据。上面选几个城市，点「开始采集」。")

# ================================================================ ② 技能
with t2:
    st.markdown("## 技能标注")
    st.markdown('<div class="flat">平台已经给每条岗位打了技能标签，但口径不统一（LLM / 大模型 / AIGC 是三个词）。'
                '我们只做两件事：把同义词归到一个标准节点；把平台漏标的从标题里补出来。'
                '认不出来的标签单独存着，交给「新词发现」节点。</div>', unsafe_allow_html=True)

    a, b = st.columns([1, 2])
    with a:
        if st.button("① 跑技能归一", type="primary"):
            box = st.status("抽取中…", expanded=True)
            SK.run_extract(log=lambda m: box.write(m))
            box.update(label="抽取完成", state="complete")
            c_demand.clear()
            c_premium.clear()
            c_cov.clear()
            st.rerun()
        kval = SK.kappa_vs_human()
        if kval.get("n"):
            st.metric("抽检一致率（cell 级）", f"{kval['agree_cells']:.1%}", f"{kval['n']} 条抽检")
            st.metric("Cohen's κ", f"{kval['kappa']:.3f}")

    with b:
        st.markdown("#### 没认出来的标签（高频在前）")
        un = SK.unknown_tags(min_n=3, limit=25)
        if un.empty:
            st.caption("还没有未识别标签，或还没跑归一。")
        else:
            st.dataframe(un.rename(columns={"tag": "原始标签", "n": "出现次数", "sample_title": "示例岗位"}),
                         width="stretch", hide_index=True, height=260)
            st.caption("这些词出现的次数达到门槛，却没进 108 个标准节点。补不补进词典，是「数据飞轮」要做的判断。")

    st.divider()
    st.markdown("#### 抽检：系统漏标了多少")
    st.caption("随机抽 8 条，你看一眼平台标签 + 系统归一结果，把漏掉的技能填进去（用逗号分隔，没漏就留空）。")
    if st.button("抽取一批样本") or "batch" not in st.session_state:
        con = sqlite3.connect(DB)
        st.session_state["batch"] = pd.read_sql(
            "SELECT jd_id,title,skills_raw FROM jobs ORDER BY RANDOM() LIMIT 8", con)
        con.close()
    batch = st.session_state.get("batch")
    if batch is not None and not batch.empty:
        con = sqlite3.connect(DB)
        rows = []
        for r in batch.itertuples():
            s = pd.read_sql("SELECT skill FROM job_skill WHERE jd_id=?", con, params=(r.jd_id,))
            raw = "、".join(json.loads(r.skills_raw or "[]"))
            rows.append({"岗位": r.title, "平台标签": raw,
                         "系统归一": "、".join(s["skill"].tolist()), "漏标补充": ""})
        con.close()
        ed = st.data_editor(pd.DataFrame(rows), width="stretch", hide_index=True,
                            disabled=["岗位", "平台标签", "系统归一"], key="ed_review")
        if st.button("提交抽检结果"):
            con = sqlite3.connect(DB)
            for i, row in ed.iterrows():
                sysl = [] if not row["系统归一"] else row["系统归一"].split("、")
                extra = [x.strip() for x in re.split(r"[,，、]", str(row["漏标补充"])) if x.strip()]
                human = sorted(set(sysl) | set(extra))
                con.execute("INSERT OR REPLACE INTO review VALUES(?,?,?,?,datetime('now'))",
                            (batch.iloc[i]["jd_id"], json.dumps(human, ensure_ascii=False),
                             json.dumps(sysl, ensure_ascii=False), 0 if extra else 1))
            con.commit()
            con.close()
            st.success("已记录，κ 会更新到左边。")
            st.session_state.pop("batch", None)

# ================================================================ ③ 分析
with t3:
    if ov.get("n", 0) == 0:
        st.info("先去 ① 采数据。")
    else:
        st.markdown("## 分析看板")
        dem = c_demand(db_ver(), 20)
        col1, col2 = st.columns([1.1, 1])
        with col1:
            st.markdown("#### 需求最高的 20 项技能")
            if dem.empty:
                st.info("还没有技能数据。先去第 ② 页点「跑技能归一」。")
            else:
                st.dataframe(
                    dem.rename(columns={"skill": "技能", "n": "岗位数", "share": "占全部岗位",
                                        "sal": "均薪", "lvl": "平均层级", "weight": "层级加权需求"}),
                    width="stretch", hide_index=True, height=430,
                    column_config={
                        "岗位数": st.column_config.ProgressColumn(
                            "岗位数", min_value=0, max_value=int(dem["n"].max()), format="%d"),
                        "占全部岗位": st.column_config.NumberColumn(format="%.1%%"),
                        "均薪": st.column_config.NumberColumn(format="¥%d"),
                    })
        with col2:
            st.markdown("#### 技能共现网络")
            st.markdown(viz.network(c_edges(db_ver())), unsafe_allow_html=True)
            st.caption("连在一起的一组技能，就是企业心里一个完整岗位的样子——这比单个技能排名更适合拿来划课程模块。")

        st.divider()
        prem = c_premium(db_ver())
        p1, p2 = st.columns([1.05, 1])
        with p1:
            st.markdown("#### 技能值多少钱")
            if prem.get("ok"):
                st.markdown(viz.premium_bars(prem["table"], 8), unsafe_allow_html=True)
                st.caption(f"5 折交叉验证 R²={prem['r2']:.3f}（不含技能的基线 {prem.get('r2_base', 0):.3f}），"
                           f"样本 {prem['n']} 条，控制城市、岗位族、企业规模、经验、学历、岗位层级。"
                           f"技能解释力有限是数据本身的特点，看系数和区间，不看拟合优度。这是关联，不是因果。")
            else:
                st.warning(prem.get("msg"))
        with p2:
            st.markdown("#### 课程覆盖与缺口")
            cov = c_cov(db_ver())
            if cov.get("ok"):
                m = st.columns(4)
                kpi(m[0], "加权覆盖率", f"{cov['coverage']:.1%}", "0.6×需求 + 0.4×溢价")
                kpi(m[1], "红色缺口", cov["red"], "需求高·覆盖≤0.5")
                kpi(m[2], "橙色缺口", cov["orange"], "覆盖不足")
                kpi(m[3], "已覆盖", cov["green"], "覆盖度=1")
                st.markdown(viz.quadrant(cov["table"]), unsafe_allow_html=True)
            else:
                st.warning(cov.get("msg"))

        st.divider()
        st.markdown("#### 城市与结构")
        cc1, cc2 = st.columns(2)
        with cc1:
            st.dataframe(A.city_profile().rename(columns={"月薪中位": "月薪中位数"}),
                         width="stretch", hide_index=True, height=300)
        with cc2:
            j = A.jobs()
            edu = j["edu"].value_counts().rename_axis("学历").reset_index(name="岗位数")
            exp = j["exp"].value_counts().rename_axis("经验").reset_index(name="岗位数")
            st.dataframe(edu, width="stretch", hide_index=True, height=140)
            st.dataframe(exp, width="stretch", hide_index=True, height=140)

# ================================================================ ④ 智能体
with t4:
    st.markdown("## 智能体工作台")
    st.markdown('<div class="flat">左边是流程，右边是节点。每个节点就是一个工具调用，依赖决定谁先跑。'
                '改完自动保存到 config/agent_flow.json，不改代码也能搭出新流程。'
                '这里没有大模型——每个数字都来自真实查询，评委问哪句就点开哪个节点。</div>',
                unsafe_allow_html=True)

    if "flow" not in st.session_state:
        st.session_state["flow"] = AG.load_flow()
    flow = st.session_state["flow"]

    left, right = st.columns([1.0, 1.1])
    with left:
        draw = st.empty()
        draw.markdown(AG.svg(flow, st.session_state.get("status", {})), unsafe_allow_html=True)
        st.caption("🔧 工具节点　🚦 校验节点　📄 成稿节点　|　绿色=出结果，红色=没通过，灰色=被上游跳过，"
                   "左侧色条表示节点类型")

        p1, p2, p3 = st.columns(3)
        flow["major"] = p1.text_input("专业", flow.get("major", "人工智能技术应用"))
        flow["city"] = p2.selectbox("城市", ["全省"] + list(crawl.CITY_ZHAOPIN),
                                    index=0 if flow.get("city", "全省") not in crawl.CITY_ZHAOPIN
                                    else list(crawl.CITY_ZHAOPIN).index(flow["city"]) + 1)
        flow["name"] = p3.text_input("流程名", flow.get("name", "专业适配度诊断"))

        b1, b2 = st.columns([1, 1])
        run_clicked = b1.button("▶ 运行流程", type="primary", width="stretch")
        if b2.button("恢复默认流程", width="stretch"):
            st.session_state["flow"] = json.loads(json.dumps(AG.DEFAULT_FLOW))
            AG.save_flow(st.session_state["flow"])
            st.rerun()

        if run_clicked:
            status = {}
            prog = st.progress(0.0, text="开始")
            total = max(len([n for n in flow["nodes"] if n.get("enabled", True)]), 1)
            done = {"i": 0}

            def on_node(nid, row):
                status[nid] = {"ok": "ok", "未通过": "fail", "报错": "error", "跳过": "skip"}.get(row["状态"], "ok")
                done["i"] += 1
                prog.progress(done["i"] / total, text=f"{row['节点']} · {row['状态']} · {row['耗时ms']}ms")
                draw.markdown(AG.svg(flow, status), unsafe_allow_html=True)

            res = AG.run(flow, {"major": flow["major"], "city": flow["city"]}, on_node=on_node)
            st.session_state["status"] = status
            st.session_state["last"] = res
            prog.empty()

        res = st.session_state.get("last")
        if res:
            if res["halted"] and not res.get("report"):
                st.warning("流程在校验节点停住了：样本量不够，按规则不出结论。把门槛调低再跑。")
            st.markdown("#### 节点调用记录")
            st.dataframe(pd.DataFrame(res["trace"])[["节点", "工具", "状态", "耗时ms", "摘要"]],
                         width="stretch", hide_index=True, height=280)
            st.caption(f"总耗时 {res['elapsed']} 秒"
                       + ("；流程在校验节点停住了，下游按规则跳过。" if res["halted"] else ""))

    with right:
        st.markdown("#### 节点配置")
        ids = [n["id"] for n in flow["nodes"]]
        for n in flow["nodes"]:
            icon = {"tool": "🔧", "gate": "🚦", "compose": "📄"}.get(n["type"], "🔧")
            with st.expander(f"{icon} {n['title']}", expanded=False):
                n["title"] = st.text_input("名称", n["title"], key=f"ti_{n['id']}")
                tools = list(AG.TOOL_SPEC)
                n["tool"] = st.selectbox("工具", tools, index=tools.index(n["tool"]) if n["tool"] in tools else 0,
                                         key=f"to_{n['id']}")
                spec = AG.TOOL_SPEC[n["tool"]]["args"]
                args = dict(n.get("args") or {})
                cols = st.columns(2)
                for i, (k, dv) in enumerate(spec.items()):
                    if k == "grade":
                        args[k] = cols[i % 2].selectbox(k, ["红", "橙", "绿", "全部"],
                                                        index=["红", "橙", "绿", "全部"].index(args.get(k, "红")),
                                                        key=f"ar_{n['id']}_{k}")
                    else:
                        args[k] = cols[i % 2].number_input(k, 1, 5000, int(args.get(k, dv)),
                                                           key=f"ar_{n['id']}_{k}")
                n["args"] = args
                others = [x for x in ids if x != n["id"]]
                n["deps"] = st.multiselect("依赖（先跑完这些才轮到我）", others,
                                           default=[d for d in n.get("deps", []) if d in others],
                                           key=f"dp_{n['id']}")
                n["enabled"] = st.checkbox("启用", n.get("enabled", True), key=f"en_{n['id']}")
                n["type"] = "compose" if n["tool"] == "compose_report" else (
                    "gate" if n["tool"] == "sample_gate" else "tool")
                if st.button("删除这个节点", key=f"del_{n['id']}"):
                    flow["nodes"] = [x for x in flow["nodes"] if x["id"] != n["id"]]
                    for x in flow["nodes"]:
                        x["deps"] = [d for d in x.get("deps", []) if d != n["id"]]
                    AG.save_flow(flow)
                    st.rerun()

        with st.form("add_node", clear_on_submit=True):
            st.markdown("**加一个节点**")
            a1, a2 = st.columns(2)
            new_title = a1.text_input("名称", placeholder="比如：按城市看需求")
            new_tool = a2.selectbox("工具", list(AG.TOOL_SPEC))
            new_deps = st.multiselect("依赖", ids, default=ids[-1:] if ids else [])
            if st.form_submit_button("添加"):
                num = max([int(re.sub(r"\D", "", x) or 0) for x in ids] + [0]) + 1
                flow["nodes"].append({
                    "id": f"n{num}", "type": "tool", "title": new_title or AG.TOOL_SPEC[new_tool]["label"],
                    "tool": new_tool, "args": dict(AG.TOOL_SPEC[new_tool]["args"]),
                    "deps": new_deps, "enabled": True})
                AG.save_flow(flow)
                st.rerun()
        AG.save_flow(flow)

        res = st.session_state.get("last")
        if res and res.get("report"):
            st.divider()
            st.markdown("#### 生成的报告")
            st.markdown(res["report"])
            st.download_button("下载 Markdown", res["report"].encode("utf-8"),
                               f"{flow['major']}_诊断报告.md", "text/markdown")
            if st.button("导出 Word"):
                path = write_docx(res["report"], flow["major"])
                st.success(f"已存到 {path}")

# ================================================================ ⑤ 说明


with t5:
    st.markdown("## 数据规范")
    st.markdown("""
**一、数据从哪来，合不合规**

只采招聘网站的公开岗位卡片：职位名、公司名、城市、薪资区间、学历经验要求、平台自己打的技能标签。
不登录、不绕验证码、不进简历库、不碰任何个人信息。每次请求间隔 2 秒左右，单个来源控制在千条量级。
公司名是公开的企业名，不做二次加工；原始数据只在本机，不对外发布。

**二、为什么不用大模型**

这个项目要回答的是"企业到底要什么技能、值多少钱、我们课程差在哪"。这三个问题的答案必须是可复算的数字。
大模型擅长把话说顺，不擅长保证数字对得上。所以流程里每个节点都是一次确定的查询或回归，
报告由模板拼装，数字从工具返回里取。好处是断网能跑、零成本、每句话都能追到来源；
代价是措辞不如模型灵活——我们接受这个代价。

**三、这套东西能被谁用**

教务处每学期跑一次，得到一份技能需求与课程缺口的对照；专业负责人拿红色缺口清单去改培养方案；
招就处拿城市和薪资结构做招生宣传的底稿。换专业只需要换两样东西：技能词典、课程-技能映射表。

---

### 目录

| 路径 | 作用 |
|---|---|
| `app.py` | 全部页面，五个标签页 |
| `core/crawl.py` | 采集智联、薪资解析 |
| `core/skills.py` | 技能归一、未识别标签、抽检 κ |
| `core/analyze.py` | 需求、共现、薪资回归、覆盖率与缺口 |
| `core/agent.py` | 流程引擎 + 流程图渲染 |
| `core/viz.py` | 三张自绘 SVG 图 |
| `config/agent_flow.json` | 智能体流程，页面上改完就存这里 |
| `config/crawl.json` | 采集配置（城市、关键词、页数） |
| `data/jobs.db` | SQLite，岗位 + 技能 + 抽检记录 |
| `docs/` | 智能体设计、操作手册、合规说明、答辩问答 |
""")
    #st.info("改流程只改 config/agent_flow.json，改词典只改 data/dict/skill_dict.csv。代码基本不用动。")

    st.divider()
    st.markdown("### 指标台账")
    #st.caption("所有对外材料（PPT、报告、海报）引用的数字只从这里抄，避免三个地方三个数。")
    if st.button("按当前库重新生成 docs/指标台账.md"):
        path = write_ledger()
        st.success(f"已更新 {path.relative_to(ROOT)}")
        st.markdown(path.read_text(encoding="utf-8"))
